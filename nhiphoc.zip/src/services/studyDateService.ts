import {
  collection,
  deleteDoc,
  doc,
  getDocs,
  query,
  runTransaction,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
} from 'firebase/firestore';
import { db, handleFirestoreError } from '../firebase';
import {
  OperationType,
  StudyDateMessageKind,
  StudyDatePhase,
  StudyDateRoom,
  StudyDateStatus,
  StudyDateVibe,
  StudyFriend,
} from '../types';
import { generateDocId } from '../utils/imageCompress';

export interface StudyDateJoinProfile {
  uid: string;
  name: string;
  major: string;
  goal: string;
  subject: string;
  strictSubjectMatch?: boolean;
  vibe: StudyDateVibe;
  durationMinutes: number;
  camOn: boolean;
  micOn: boolean;
}

function clampStr(val: string, fallback: string, maxLen: number): string {
  const cleaned = val.trim().slice(0, maxLen);
  return cleaned || fallback;
}

function normalizeSubject(val: string): string {
  return val.trim().toLowerCase().replace(/\s+/g, ' ');
}

export function getFriendPairIds(uid1: string, uid2: string): {
  pairId: string;
  uidA: string;
  uidB: string;
  firstIsUid1: boolean;
} {
  if (uid1 < uid2) {
    return { pairId: `${uid1}_${uid2}`, uidA: uid1, uidB: uid2, firstIsUid1: true };
  }
  return { pairId: `${uid2}_${uid1}`, uidA: uid2, uidB: uid1, firstIsUid1: false };
}

export async function cleanupOwnWaitingRooms(uid: string): Promise<void> {
  try {
    const snap = await getDocs(
      query(
        collection(db, 'study_date_rooms'),
        where('hostUid', '==', uid),
        where('status', '==', 'waiting'),
      ),
    );
    await Promise.all(
      snap.docs.map((d) => {
        const room = d.data() as StudyDateRoom;
        if (!room.guestUid) {
          return deleteDoc(d.ref);
        }
        return Promise.resolve();
      }),
    );
  } catch (err) {
    console.warn('Cleanup waiting rooms skipped:', err);
  }
}

export async function cleanupUserStudyFriends(uid: string): Promise<void> {
  try {
    const [snapA, snapB] = await Promise.all([
      getDocs(query(collection(db, 'study_friends'), where('uidA', '==', uid))),
      getDocs(query(collection(db, 'study_friends'), where('uidB', '==', uid))),
    ]);
    await Promise.all([
      ...snapA.docs.map((d) => deleteDoc(d.ref)),
      ...snapB.docs.map((d) => deleteDoc(d.ref)),
    ]);
  } catch (err) {
    console.warn('Cleanup study friends skipped:', err);
  }
}

export async function joinWaitingStudyDateRoom(
  roomId: string,
  profile: StudyDateJoinProfile,
): Promise<boolean> {
  const roomRef = doc(db, 'study_date_rooms', roomId);
  const cleanName = clampStr(profile.name, 'Sinh viên Nhiphoc', 80);
  const cleanMajor = clampStr(profile.major, 'Sinh viên Đại học', 80);
  const cleanGoal = clampStr(profile.goal, 'Tập trung ôn bài cùng nhau', 160);

  try {
    const joined = await runTransaction(db, async (tx) => {
      const snap = await tx.get(roomRef);
      if (!snap.exists()) return false;
      const room = snap.data() as StudyDateRoom;
      if (room.status !== 'waiting' || room.guestUid !== '' || room.hostUid === profile.uid) {
        return false;
      }
      if (room.invitedFriendUid && room.invitedFriendUid !== profile.uid) {
        return false;
      }

      tx.update(roomRef, {
        guestUid: profile.uid,
        guestName: cleanName,
        guestMajor: cleanMajor,
        guestGoal: cleanGoal,
        guestReady: false,
        guestCamOn: profile.camOn,
        guestMicOn: profile.micOn,
        status: 'matched',
        updatedAt: serverTimestamp(),
      });
      return true;
    });
    return joined;
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `study_date_rooms/${roomId}`);
    return false;
  }
}

export async function findOrCreateStudyDateRoom(
  profile: StudyDateJoinProfile,
): Promise<{ roomId: string; role: 'host' | 'guest' }> {
  await cleanupOwnWaitingRooms(profile.uid);

  const nowMs = Date.now();
  const maxAgeMs = 30 * 60 * 1000;
  const cleanSubject = clampStr(profile.subject, 'Mọi môn học', 60);
  const normDesired = normalizeSubject(cleanSubject);
  const isSpecificSubject = normDesired !== '' && normDesired !== 'mọi môn học' && normDesired !== 'tất cả';

  let candidates: StudyDateRoom[] = [];
  try {
    const snap = await getDocs(
      query(
        collection(db, 'study_date_rooms'),
        where('status', '==', 'waiting'),
        where('invitedFriendUid', '==', ''),
      ),
    );
    candidates = snap.docs
      .map((d) => d.data() as StudyDateRoom)
      .filter((r) => {
        if (r.hostUid === profile.uid || r.guestUid !== '') return false;
        const createdMs = r.createdAt?.toMillis?.() || nowMs;
        if (nowMs - createdMs > maxAgeMs) return false;
        if (profile.strictSubjectMatch && isSpecificSubject) {
          return normalizeSubject(r.subject || '') === normDesired;
        }
        return true;
      })
      .sort((a, b) => {
        const aSubMatch =
          isSpecificSubject && normalizeSubject(a.subject || '') === normDesired ? 4 : 0;
        const bSubMatch =
          isSpecificSubject && normalizeSubject(b.subject || '') === normDesired ? 4 : 0;
        const aScore =
          aSubMatch +
          (a.vibe === profile.vibe ? 2 : 0) +
          (a.durationMinutes === profile.durationMinutes ? 1 : 0);
        const bScore =
          bSubMatch +
          (b.vibe === profile.vibe ? 2 : 0) +
          (b.durationMinutes === profile.durationMinutes ? 1 : 0);
        if (bScore !== aScore) return bScore - aScore;
        return (b.createdAt?.toMillis?.() || 0) - (a.createdAt?.toMillis?.() || 0);
      });
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'study_date_rooms');
  }

  for (const cand of candidates) {
    const ok = await joinWaitingStudyDateRoom(cand.id, profile);
    if (ok) {
      return { roomId: cand.id, role: 'guest' };
    }
  }

  // No eligible waiting room found -> create a new waiting room as host
  const roomId = generateDocId('sd');
  const durationMins = Math.max(10, Math.min(180, Math.round(profile.durationMinutes)));
  const cleanName = clampStr(profile.name, 'Sinh viên Nhiphoc', 80);
  const cleanMajor = clampStr(profile.major, 'Sinh viên Đại học', 80);
  const cleanGoal = clampStr(profile.goal, 'Tập trung ôn bài cùng nhau', 160);

  try {
    await setDoc(doc(db, 'study_date_rooms', roomId), {
      id: roomId,
      hostUid: profile.uid,
      hostName: cleanName,
      hostMajor: cleanMajor,
      hostGoal: cleanGoal,
      hostReady: true,
      hostCamOn: profile.camOn,
      hostMicOn: profile.micOn,
      guestUid: '',
      guestName: '',
      guestMajor: '',
      guestGoal: '',
      guestReady: false,
      guestCamOn: false,
      guestMicOn: false,
      vibe: profile.vibe,
      durationMinutes: durationMins,
      phase: 'focus',
      timerRunning: false,
      timerEndAtMs: 0,
      remainingSeconds: durationMins * 60,
      offerSdp: '',
      answerSdp: '',
      subject: cleanSubject,
      sharedTopic: '',
      invitedFriendUid: '',
      hostWantsFriend: false,
      guestWantsFriend: false,
      status: 'waiting',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, `study_date_rooms/${roomId}`);
  }

  return { roomId, role: 'host' };
}

export async function inviteBestFriendToStudyDate(
  profile: StudyDateJoinProfile,
  friendUid: string,
): Promise<string> {
  await cleanupOwnWaitingRooms(profile.uid);

  const roomId = generateDocId('sdf');
  const durationMins = Math.max(10, Math.min(180, Math.round(profile.durationMinutes)));
  const cleanName = clampStr(profile.name, 'Sinh viên Nhiphoc', 80);
  const cleanMajor = clampStr(profile.major, 'Sinh viên Đại học', 80);
  const cleanGoal = clampStr(profile.goal, 'Hẹn bạn thân cùng ôn tập', 160);
  const cleanSubject = clampStr(profile.subject, 'Mọi môn học', 60);

  try {
    await setDoc(doc(db, 'study_date_rooms', roomId), {
      id: roomId,
      hostUid: profile.uid,
      hostName: cleanName,
      hostMajor: cleanMajor,
      hostGoal: cleanGoal,
      hostReady: true,
      hostCamOn: profile.camOn,
      hostMicOn: profile.micOn,
      guestUid: '',
      guestName: '',
      guestMajor: '',
      guestGoal: '',
      guestReady: false,
      guestCamOn: false,
      guestMicOn: false,
      vibe: profile.vibe,
      durationMinutes: durationMins,
      phase: 'focus',
      timerRunning: false,
      timerEndAtMs: 0,
      remainingSeconds: durationMins * 60,
      offerSdp: '',
      answerSdp: '',
      subject: cleanSubject,
      sharedTopic: '',
      invitedFriendUid: friendUid,
      hostWantsFriend: false,
      guestWantsFriend: false,
      status: 'waiting',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, `study_date_rooms/${roomId}`);
  }

  return roomId;
}

export async function updateStudyDateHostMedia(
  roomId: string,
  patch: Partial<{
    hostReady: boolean;
    hostCamOn: boolean;
    hostMicOn: boolean;
    offerSdp: string;
  }>,
): Promise<void> {
  try {
    await updateDoc(doc(db, 'study_date_rooms', roomId), {
      ...patch,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `study_date_rooms/${roomId}`);
  }
}

export async function updateStudyDateGuestMedia(
  roomId: string,
  patch: Partial<{
    guestReady: boolean;
    guestCamOn: boolean;
    guestMicOn: boolean;
    answerSdp: string;
  }>,
): Promise<void> {
  try {
    await updateDoc(doc(db, 'study_date_rooms', roomId), {
      ...patch,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `study_date_rooms/${roomId}`);
  }
}

export async function updateStudyDateTimerState(
  roomId: string,
  patch: {
    status: Extract<StudyDateStatus, 'matched' | 'active'>;
    phase: StudyDatePhase;
    timerRunning: boolean;
    timerEndAtMs: number;
    remainingSeconds: number;
  },
): Promise<void> {
  try {
    await updateDoc(doc(db, 'study_date_rooms', roomId), {
      ...patch,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `study_date_rooms/${roomId}`);
  }
}

export async function updateStudyDateSharedTopic(
  roomId: string,
  params: {
    subject: string;
    sharedTopic: string;
  },
): Promise<void> {
  try {
    await updateDoc(doc(db, 'study_date_rooms', roomId), {
      subject: clampStr(params.subject, 'Mọi môn học', 60),
      sharedTopic: params.sharedTopic.trim().slice(0, 140),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `study_date_rooms/${roomId}`);
  }
}

export async function toggleStudyDateFriendRequest(
  room: StudyDateRoom,
  uid: string,
  wantsFriend: boolean,
): Promise<void> {
  const isHost = room.hostUid === uid;
  const patch = isHost
    ? { hostWantsFriend: wantsFriend, updatedAt: serverTimestamp() }
    : { guestWantsFriend: wantsFriend, updatedAt: serverTimestamp() };
  try {
    await updateDoc(doc(db, 'study_date_rooms', room.id), patch);
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `study_date_rooms/${room.id}`);
  }
}

export async function createStudyFriendFromRoom(
  room: StudyDateRoom,
  creatorUid: string,
): Promise<StudyFriend | null> {
  if (!room.guestUid || !room.hostWantsFriend || !room.guestWantsFriend) {
    return null;
  }

  const { pairId, uidA, uidB, firstIsUid1 } = getFriendPairIds(room.hostUid, room.guestUid);

  try {
    const existingSnap = await getDocs(
      query(
        collection(db, 'study_friends'),
        where('uidA', '==', uidA),
        where('uidB', '==', uidB),
      ),
    );
    if (!existingSnap.empty) {
      return existingSnap.docs[0].data() as StudyFriend;
    }

    const nameA = firstIsUid1
      ? clampStr(room.hostName, 'Sinh viên Nhiphoc', 80)
      : clampStr(room.guestName, 'Sinh viên Nhiphoc', 80);
    const majorA = firstIsUid1
      ? clampStr(room.hostMajor, 'Sinh viên Đại học', 80)
      : clampStr(room.guestMajor, 'Sinh viên Đại học', 80);
    const nameB = firstIsUid1
      ? clampStr(room.guestName, 'Sinh viên Nhiphoc', 80)
      : clampStr(room.hostName, 'Sinh viên Nhiphoc', 80);
    const majorB = firstIsUid1
      ? clampStr(room.guestMajor, 'Sinh viên Đại học', 80)
      : clampStr(room.hostMajor, 'Sinh viên Đại học', 80);

    await setDoc(doc(db, 'study_friends', pairId), {
      id: pairId,
      uidA,
      uidB,
      nameA,
      majorA,
      nameB,
      majorB,
      commonSubject: clampStr(room.subject || 'Mọi môn học', 'Mọi môn học', 60),
      sourceRoomId: room.id,
      createdBy: creatorUid,
      createdAt: serverTimestamp(),
    });
  } catch (error) {
    // Handle tiny race window when both students accept at the exact same moment
    const code = (error as { code?: string })?.code || '';
    if (code === 'permission-denied' || code === 'already-exists') {
      const retrySnap = await getDocs(
        query(
          collection(db, 'study_friends'),
          where('uidA', '==', uidA),
          where('uidB', '==', uidB),
        ),
      );
      if (!retrySnap.empty) {
        return retrySnap.docs[0].data() as StudyFriend;
      }
    }
    handleFirestoreError(error, OperationType.CREATE, `study_friends/${pairId}`);
  }
  return null;
}

export async function removeStudyFriend(friendPairId: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'study_friends', friendPairId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `study_friends/${friendPairId}`);
  }
}

export async function leaveOrEndStudyDateRoom(room: StudyDateRoom, uid: string): Promise<void> {
  const ref = doc(db, 'study_date_rooms', room.id);
  try {
    if (room.status === 'waiting' && room.hostUid === uid && room.guestUid === '') {
      await deleteDoc(ref);
      return;
    }
    if (room.status !== 'ended') {
      await updateDoc(ref, {
        status: 'ended',
        timerRunning: false,
        updatedAt: serverTimestamp(),
      });
    }
  } catch (error) {
    console.warn('Leave study date room warning:', error);
  }
}

export async function sendStudyDateMessage(params: {
  room: StudyDateRoom;
  senderUid: string;
  senderName: string;
  kind: StudyDateMessageKind;
  content: string;
}): Promise<void> {
  const id = generateDocId('sdm');
  const cleanContent = params.content.trim().slice(0, 600);
  if (!cleanContent) return;

  try {
    await setDoc(doc(db, 'study_date_rooms', params.room.id, 'messages', id), {
      id,
      roomId: params.room.id,
      hostUid: params.room.hostUid,
      guestUid: params.room.guestUid,
      senderUid: params.senderUid,
      senderName: clampStr(params.senderName, 'Sinh viên', 80),
      kind: params.kind,
      content: cleanContent,
      createdAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(
      error,
      OperationType.CREATE,
      `study_date_rooms/${params.room.id}/messages/${id}`,
    );
  }
}

export async function addStudyDateNote(params: {
  room: StudyDateRoom;
  createdBy: string;
  authorName: string;
  content: string;
}): Promise<void> {
  const id = generateDocId('sdn');
  const cleanContent = params.content.trim().slice(0, 300);
  if (!cleanContent) return;

  try {
    await setDoc(doc(db, 'study_date_rooms', params.room.id, 'study_notes', id), {
      id,
      roomId: params.room.id,
      hostUid: params.room.hostUid,
      guestUid: params.room.guestUid,
      createdBy: params.createdBy,
      authorName: clampStr(params.authorName, 'Sinh viên', 80),
      content: cleanContent,
      checked: false,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(
      error,
      OperationType.CREATE,
      `study_date_rooms/${params.room.id}/study_notes/${id}`,
    );
  }
}

export async function toggleStudyDateNote(params: {
  roomId: string;
  noteId: string;
  checked: boolean;
}): Promise<void> {
  try {
    await updateDoc(doc(db, 'study_date_rooms', params.roomId, 'study_notes', params.noteId), {
      checked: params.checked,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(
      error,
      OperationType.UPDATE,
      `study_date_rooms/${params.roomId}/study_notes/${params.noteId}`,
    );
  }
}

export async function deleteStudyDateNote(params: {
  roomId: string;
  noteId: string;
}): Promise<void> {
  try {
    await deleteDoc(doc(db, 'study_date_rooms', params.roomId, 'study_notes', params.noteId));
  } catch (error) {
    handleFirestoreError(
      error,
      OperationType.DELETE,
      `study_date_rooms/${params.roomId}/study_notes/${params.noteId}`,
    );
  }
}

export async function sendStudyDateIceCandidate(params: {
  room: StudyDateRoom;
  senderUid: string;
  candidate: RTCIceCandidateInit;
}): Promise<void> {
  const candStr = (params.candidate.candidate || '').slice(0, 1000);
  if (!candStr) return;

  const id = generateDocId('ice');
  try {
    await setDoc(doc(db, 'study_date_rooms', params.room.id, 'ice_candidates', id), {
      id,
      roomId: params.room.id,
      hostUid: params.room.hostUid,
      guestUid: params.room.guestUid,
      senderUid: params.senderUid,
      candidate: candStr,
      sdpMid: String(params.candidate.sdpMid || '').slice(0, 64),
      sdpMLineIndex: Math.max(0, Math.min(32, Number(params.candidate.sdpMLineIndex ?? 0))),
      createdAt: serverTimestamp(),
    });
  } catch (error) {
    console.warn('ICE candidate signaling write skipped:', error);
  }
}
