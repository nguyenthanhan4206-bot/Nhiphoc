import React, { useState } from 'react';
import { User } from 'firebase/auth';
import { motion } from 'motion/react';
import {
  ArrowRight,
  BookOpen,
  Camera,
  Check,
  CheckCheck,
  CheckCircle2,
  GraduationCap,
  HeartHandshake,
  LogOut,
  ShieldCheck,
  Trees,
  Users,
} from 'lucide-react';
import { UserRole } from '../types';
import { MascotAvatar, NhiphocRhythmMark, STUDY_BANNER_IMAGE_PATH } from './MascotAvatar';

interface AuthOnboardingProps {
  firebaseUser: User | null;
  authLoading: boolean;
  authError: string | null;
  onGoogleSignIn: () => Promise<void>;
  onSignOut: () => Promise<void>;
  onCompleteRegistration: (data: {
    displayName: string;
    phone: string;
    role: UserRole;
    studentName?: string;
    grade?: string;
    linkCodeInput?: string;
  }) => Promise<void>;
}

const ROLE_CARDS: Array<{
  role: UserRole;
  title: string;
  subtitle: string;
  features: string[];
  icon: React.FC<{ className?: string }>;
}> = [
  {
    role: 'student',
    title: 'Học sinh / SV',
    subtitle: 'Tự giác, nuôi cây & StudyWithMe Date',
    features: [
      'Bài tập hôm nay & chụp ảnh nộp bài trực tiếp',
      'Cây tập trung & đồng hồ Pomodoro xanh dịu',
      'StudyWithMe Date ghép đôi học từ xa cho sinh viên',
    ],
    icon: GraduationCap,
  },
  {
    role: 'parent',
    title: 'Cha mẹ',
    subtitle: 'Giao diện tối đơn giản, an tâm',
    features: [
      'Liên lạc trực tiếp & đặt lịch hẹn cùng trợ lý',
      'Kiểm tra tiến độ & xem ảnh bài tập của con',
      'Gửi phản hồi hoặc yêu cầu trợ giúp nhanh chóng',
    ],
    icon: HeartHandshake,
  },
  {
    role: 'assistant',
    title: 'Trợ lý',
    subtitle: 'Theo dõi & chấm bài thời gian thực',
    features: [
      'Quản lý danh sách học sinh theo dõi & giao bài mới',
      'Kiểm tra tiến độ, chấm bài ảnh & gửi nhận xét ngay',
      'Bật trạng thái Đang trực & phản hồi phụ huynh',
    ],
    icon: Users,
  },
];

export const AuthOnboarding: React.FC<AuthOnboardingProps> = ({
  firebaseUser,
  authLoading,
  authError,
  onGoogleSignIn,
  onSignOut,
  onCompleteRegistration,
}) => {
  const [selectedRole, setSelectedRole] = useState<UserRole>('student');
  const [displayName, setDisplayName] = useState(firebaseUser?.displayName || '');
  const [phone, setPhone] = useState('');
  const [joinMode, setJoinMode] = useState<'new' | 'code'>('new');
  const [studentName, setStudentName] = useState('');
  const [grade, setGrade] = useState('Lớp 8');
  const [linkCodeInput, setLinkCodeInput] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);
  const [bannerError, setBannerError] = useState(false);

  React.useEffect(() => {
    if (firebaseUser?.displayName && !displayName) {
      setDisplayName(firebaseUser.displayName);
    }
  }, [firebaseUser, displayName]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    if (!displayName.trim()) {
      setFormError('Vui lòng nhập họ và tên của bạn.');
      return;
    }
    if (joinMode === 'code' && !linkCodeInput.trim()) {
      setFormError('Vui lòng nhập mã kết nối học sinh (ví dụ: NH842K19).');
      return;
    }
    if (joinMode === 'new' && selectedRole !== 'student' && !studentName.trim()) {
      setFormError('Vui lòng nhập tên học sinh cần theo dõi.');
      return;
    }

    setSubmitting(true);
    try {
      await onCompleteRegistration({
        displayName,
        phone,
        role: selectedRole,
        studentName: selectedRole === 'student' ? displayName : studentName,
        grade,
        linkCodeInput: joinMode === 'code' ? linkCodeInput : '',
      });
    } catch (err) {
      setFormError(err instanceof Error ? err.message : 'Đăng ký thất bại, vui lòng thử lại.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#F3F8F4] text-[#0F2A1E] flex flex-col">
      {/* Top Bar Contract: 3 exact zones */}
      <header className="border-b border-[#D5E6DA] bg-white/90 backdrop-blur-md sticky top-0 z-30">
        <div className="max-w-[1320px] mx-auto px-6 py-3.5 flex items-center justify-between gap-8">
          <a
            href="#top"
            className="flex items-center gap-3 text-xl font-extrabold tracking-tight text-[#114B32] whitespace-nowrap shrink-0 font-display"
          >
            <MascotAvatar size="sm" />
            <span>Nhiphoc</span>
          </a>

          <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-[#426352]">
            <a href="#roles-preview" className="hover:text-[#114B32] transition-colors whitespace-nowrap shrink-0">
              Ba giao diện
            </a>
            <a href="#workflow" className="hover:text-[#114B32] transition-colors whitespace-nowrap shrink-0">
              Nhịp học tập
            </a>
            <a href="#register-panel" className="hover:text-[#114B32] transition-colors whitespace-nowrap shrink-0">
              Đăng ký tài khoản
            </a>
          </nav>

          <div className="flex items-center gap-3 shrink-0">
            {firebaseUser ? (
              <button
                type="button"
                onClick={onSignOut}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-xl border border-[#C9E0D0] bg-white text-xs font-semibold text-[#0F2A1E] hover:bg-[#EAF4ED] transition-colors whitespace-nowrap shrink-0"
              >
                <LogOut className="w-3.5 h-3.5" />
                Đổi tài khoản
              </button>
            ) : (
              <button
                type="button"
                onClick={onGoogleSignIn}
                disabled={authLoading}
                className="px-4 py-2 rounded-xl bg-[#114B32] text-white text-xs font-semibold hover:bg-[#0D3B27] disabled:opacity-50 transition-colors whitespace-nowrap shrink-0"
              >
                Đăng nhập Google
              </button>
            )}
          </div>
        </div>
      </header>

      <main id="top" className="flex-1">
        {/* Hero Split */}
        <section className="relative overflow-hidden border-b border-[#D5E6DA]">
          <div className="absolute inset-0 nhiphoc-grid-bg opacity-45 pointer-events-none" />
          <div className="relative max-w-[1320px] mx-auto px-6 py-10 lg:py-14 grid grid-cols-1 lg:grid-cols-12 gap-10 items-stretch">
            {/* Left Brand & Mascot Anchor */}
            <div className="lg:col-span-7 flex flex-col justify-between space-y-7">
              <div className="space-y-5">
                <div className="flex items-center gap-3 text-xs font-semibold text-[#186A47]">
                  <NhiphocRhythmMark />
                  <span>Không gian học tập xanh pastel · Học sinh · Cha mẹ · Trợ lý</span>
                </div>

                <h1
                  className="text-3xl sm:text-5xl font-extrabold tracking-tight text-[#0F2A1E] leading-[1.12]"
                  style={{ textWrap: 'balance' }}
                >
                  Giữ nhịp học mỗi ngày cùng người bạn xanh{' '}
                  <span className="text-[#186A47]">Nhiphoc</span>
                </h1>

                <p className="text-base text-[#3D5D4D] leading-relaxed max-w-2xl">
                  Thiết kế tối giản với sắc xanh lá pastel dịu mắt và xanh rừng sâu nhận diện rõ
                  ràng. Học sinh chụp ảnh nộp bài tập và nuôi Cây tập trung, Trợ lý chấm bài trực
                  tiếp hoặc sau 1 giờ, Cha mẹ theo dõi an tâm trong giao diện tối thư thái.
                </p>
              </div>

              {/* Signature Deep Forest Green Mascot Card + Study Sanctuary Split */}
              <div className="rounded-3xl border border-[#C6DFCD] bg-white overflow-hidden shadow-[0_18px_48px_-28px_rgba(17,75,50,0.22)]">
                <div className="grid grid-cols-1 sm:grid-cols-12 items-stretch">
                  <div className="sm:col-span-6 bg-[#114B32] text-white p-6 sm:p-7 flex flex-col justify-between gap-5">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-semibold text-[#BCE3C7]">
                        Linh vật đại diện
                      </span>
                      <NhiphocRhythmMark dark />
                    </div>

                    <div className="flex items-center gap-5">
                      <motion.div
                        animate={{ y: [0, -5, 0] }}
                        transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
                      >
                        <MascotAvatar size="2xl" className="border-2 border-[#A7D7B8] shadow-md" />
                      </motion.div>
                      <div className="space-y-1.5">
                        <p className="text-xl font-bold font-display text-white">
                          Mầm Cú Nhiphoc
                        </p>
                        <p className="text-xs text-[#CBEAD4] leading-relaxed">
                          Xanh lá và trắng tinh giản — nhắc nhịp làm bài, giữ giờ tập trung và báo
                          tin khi trợ lý chấm xong.
                        </p>
                      </div>
                    </div>

                    <div className="pt-3 border-t border-white/15 flex items-center justify-between text-xs text-[#CBEAD4] tabular-nums">
                      <span>3 vai trò đồng bộ</span>
                      <span>Phản hồi tức thì / sau 1h</span>
                    </div>
                  </div>

                  <div className="sm:col-span-6 relative min-h-[240px] bg-[#E5F2E9]">
                    {!bannerError ? (
                      <img
                        src={STUDY_BANNER_IMAGE_PATH}
                        alt="Góc bàn học xanh pastel tối giản Nhiphoc"
                        referrerPolicy="no-referrer"
                        onError={() => setBannerError(true)}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex flex-col items-center justify-center p-6 text-center text-[#114B32]">
                        <BookOpen className="w-8 h-8 mb-2" />
                        <p className="text-sm font-semibold">Không gian học tập Nhiphoc</p>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* Right Auth & Registration Panel */}
            <div id="register-panel" className="lg:col-span-5 flex flex-col">
              <div className="flex-1 rounded-3xl border border-[#C6DFCD] bg-white p-6 sm:p-8 flex flex-col justify-between shadow-[0_20px_50px_-24px_rgba(17,75,50,0.18)]">
                {!firebaseUser ? (
                  <div className="space-y-6">
                    <div>
                      <p className="text-xs font-semibold text-[#186A47]">
                        Bước 1 · Chọn vai trò & Đăng nhập
                      </p>
                      <h2 className="text-2xl font-extrabold text-[#0F2A1E] mt-1">
                        Vào không gian Nhiphoc
                      </h2>
                      <p className="text-sm text-[#426352] mt-2 leading-relaxed">
                        Tài khoản đồng bộ thực tế trên mọi thiết bị. Chọn vai trò bạn muốn sử dụng
                        ngay bên dưới.
                      </p>
                    </div>

                    {/* Interactive Role Switcher */}
                    <div className="space-y-2.5">
                      <p className="text-xs font-semibold text-[#0F2A1E]">
                        Bạn là ai trong Nhiphoc?
                      </p>
                      <div className="grid grid-cols-3 gap-2 p-1.5 rounded-2xl bg-[#EAF4ED] border border-[#CFE3D5]">
                        {ROLE_CARDS.map((item) => {
                          const Icon = item.icon;
                          const active = selectedRole === item.role;
                          return (
                            <button
                              key={item.role}
                              type="button"
                              onClick={() => setSelectedRole(item.role)}
                              className={`py-2.5 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 whitespace-nowrap ${
                                active
                                  ? 'bg-[#114B32] text-white shadow-sm'
                                  : 'text-[#3D5D4D] hover:text-[#0F2A1E]'
                              }`}
                            >
                              <Icon className="w-3.5 h-3.5 shrink-0" />
                              <span>{item.title}</span>
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    {/* Selected Role Feature Preview */}
                    <div
                      className={`rounded-2xl border p-5 space-y-3 transition-colors ${
                        selectedRole === 'parent'
                          ? 'bg-[#0E1813] border-[#253D30] text-[#EFF6F2]'
                          : 'bg-[#F4FAF6] border-[#CFE3D5] text-[#0F2A1E]'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <p
                          className={`text-xs font-bold ${
                            selectedRole === 'parent' ? 'text-[#9AD9B0]' : 'text-[#114B32]'
                          }`}
                        >
                          Giao diện {ROLE_CARDS.find((r) => r.role === selectedRole)?.title}
                        </p>
                        <span
                          className={`text-[11px] ${
                            selectedRole === 'parent' ? 'text-[#9AB5A5]' : 'text-[#426352]'
                          }`}
                        >
                          {ROLE_CARDS.find((r) => r.role === selectedRole)?.subtitle}
                        </span>
                      </div>

                      <ul className="space-y-2">
                        {ROLE_CARDS.find((r) => r.role === selectedRole)?.features.map((feat) => (
                          <li key={feat} className="flex items-start gap-2.5 text-xs leading-relaxed">
                            <CheckCircle2
                              className={`w-4 h-4 shrink-0 mt-0.5 ${
                                selectedRole === 'parent' ? 'text-[#9AD9B0]' : 'text-[#186A47]'
                              }`}
                            />
                            <span>{feat}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {authError && (
                      <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-xs text-red-700">
                        {authError}
                      </div>
                    )}

                    <div className="space-y-3 pt-1">
                      <button
                        type="button"
                        onClick={onGoogleSignIn}
                        disabled={authLoading}
                        className="w-full py-3.5 px-5 rounded-2xl bg-[#114B32] text-white text-sm font-bold hover:bg-[#0D3B27] disabled:opacity-50 transition-colors flex items-center justify-center gap-3 shadow-sm"
                      >
                        <ShieldCheck className="w-4 h-4 text-[#A7D7B8]" />
                        <span>
                          {authLoading ? 'Đang mở đăng nhập...' : 'Đăng nhập / Đăng ký bằng Google'}
                        </span>
                        <ArrowRight className="w-4 h-4" />
                      </button>
                      <p className="text-[11px] text-[#527361] text-center leading-relaxed">
                        Chỉ mất 10 giây · Dữ liệu lưu trên Cloud Firestore để đăng nhập lại ở mọi
                        thiết bị.
                      </p>
                    </div>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} className="space-y-5">
                    <div className="flex items-center justify-between gap-4 border-b border-[#E3EFE7] pb-4">
                      <div>
                        <p className="text-xs font-semibold text-[#186A47]">
                          Bước 2 · Hồ sơ Nhiphoc
                        </p>
                        <h2 className="text-xl font-extrabold text-[#0F2A1E] mt-0.5">
                          Hoàn tất thông tin tài khoản
                        </h2>
                      </div>
                      <MascotAvatar size="sm" />
                    </div>

                    <div className="text-xs text-[#3D5D4D] bg-[#F4FAF6] border border-[#CFE3D5] rounded-xl px-3.5 py-2.5 flex items-center justify-between gap-2">
                      <span className="truncate">{firebaseUser.email}</span>
                      <span className="font-bold text-[#114B32] shrink-0">Đã xác thực</span>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-[#0F2A1E] mb-1.5">
                        Vai trò của bạn
                      </label>
                      <div className="grid grid-cols-3 gap-2 p-1.5 rounded-2xl bg-[#EAF4ED] border border-[#CFE3D5]">
                        {ROLE_CARDS.map((item) => {
                          const active = selectedRole === item.role;
                          return (
                            <button
                              key={item.role}
                              type="button"
                              onClick={() => setSelectedRole(item.role)}
                              className={`py-2 px-3 rounded-xl text-xs font-bold transition-colors whitespace-nowrap ${
                                active
                                  ? 'bg-[#114B32] text-white shadow-sm'
                                  : 'text-[#3D5D4D] hover:text-[#0F2A1E]'
                              }`}
                            >
                              {item.title}
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                      <div>
                        <label
                          htmlFor="reg-name"
                          className="block text-xs font-semibold text-[#0F2A1E] mb-1.5"
                        >
                          Họ và tên
                        </label>
                        <input
                          id="reg-name"
                          type="text"
                          required
                          maxLength={80}
                          value={displayName}
                          onChange={(e) => setDisplayName(e.target.value)}
                          placeholder="Nguyễn Minh An"
                          className="w-full rounded-xl border border-[#C9E0D0] px-3.5 py-2.5 text-sm text-[#0F2A1E] focus:outline-none focus:ring-2 focus:ring-[#114B32]/20 focus:border-[#114B32]"
                        />
                      </div>
                      <div>
                        <label
                          htmlFor="reg-phone"
                          className="block text-xs font-semibold text-[#0F2A1E] mb-1.5"
                        >
                          Số điện thoại
                        </label>
                        <input
                          id="reg-phone"
                          type="tel"
                          maxLength={30}
                          value={phone}
                          onChange={(e) => setPhone(e.target.value)}
                          placeholder="0912 345 678"
                          className="w-full rounded-xl border border-[#C9E0D0] px-3.5 py-2.5 text-sm text-[#0F2A1E] focus:outline-none focus:ring-2 focus:ring-[#114B32]/20 focus:border-[#114B32]"
                        />
                      </div>
                    </div>

                    <div className="space-y-3 pt-1">
                      <div className="flex items-center gap-2 p-1 rounded-xl bg-[#EAF4ED] border border-[#CFE3D5]">
                        <button
                          type="button"
                          onClick={() => setJoinMode('new')}
                          className={`flex-1 py-2 px-3 rounded-lg text-xs font-bold transition-colors whitespace-nowrap ${
                            joinMode === 'new'
                              ? 'bg-white text-[#0F2A1E] shadow-sm'
                              : 'text-[#426352] hover:text-[#0F2A1E]'
                          }`}
                        >
                          Tạo hồ sơ học sinh mới
                        </button>
                        <button
                          type="button"
                          onClick={() => setJoinMode('code')}
                          className={`flex-1 py-2 px-3 rounded-lg text-xs font-bold transition-colors whitespace-nowrap ${
                            joinMode === 'code'
                              ? 'bg-white text-[#0F2A1E] shadow-sm'
                              : 'text-[#426352] hover:text-[#0F2A1E]'
                          }`}
                        >
                          Nhập mã kết nối (NH...)
                        </button>
                      </div>

                      {joinMode === 'new' ? (
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                          {selectedRole !== 'student' && (
                            <div>
                              <label
                                htmlFor="reg-student-name"
                                className="block text-xs font-semibold text-[#0F2A1E] mb-1.5"
                              >
                                Tên học sinh
                              </label>
                              <input
                                id="reg-student-name"
                                type="text"
                                maxLength={80}
                                value={studentName}
                                onChange={(e) => setStudentName(e.target.value)}
                                placeholder="Bé Gia Bảo"
                                className="w-full rounded-xl border border-[#C9E0D0] px-3.5 py-2.5 text-sm text-[#0F2A1E] focus:outline-none focus:ring-2 focus:ring-[#114B32]/20"
                              />
                            </div>
                          )}
                          <div className={selectedRole === 'student' ? 'sm:col-span-2' : ''}>
                            <label
                              htmlFor="reg-grade"
                              className="block text-xs font-semibold text-[#0F2A1E] mb-1.5"
                            >
                              Khối / Bậc học
                            </label>
                            <input
                              id="reg-grade"
                              type="text"
                              maxLength={40}
                              value={grade}
                              onChange={(e) => setGrade(e.target.value)}
                              placeholder="Lớp 8 hoặc Sinh viên Đại học"
                              className="w-full rounded-xl border border-[#C9E0D0] px-3.5 py-2.5 text-sm text-[#0F2A1E] focus:outline-none focus:ring-2 focus:ring-[#114B32]/20"
                            />
                            <div className="flex flex-wrap gap-1.5 mt-2">
                              {['Lớp 8', 'Lớp 12', 'Sinh viên Đại học'].map((preset) => (
                                <button
                                  key={preset}
                                  type="button"
                                  onClick={() => setGrade(preset)}
                                  className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-colors ${
                                    grade === preset
                                      ? 'bg-[#114B32] text-white'
                                      : 'bg-[#EAF4ED] text-[#3D5D4D] hover:text-[#0F2A1E]'
                                  }`}
                                >
                                  {preset}
                                </button>
                              ))}
                            </div>
                          </div>
                        </div>
                      ) : (
                        <div>
                          <label
                            htmlFor="reg-link-code"
                            className="block text-xs font-semibold text-[#0F2A1E] mb-1.5"
                          >
                            Mã kết nối học sinh (NH...)
                          </label>
                          <input
                            id="reg-link-code"
                            type="text"
                            maxLength={12}
                            value={linkCodeInput}
                            onChange={(e) => setLinkCodeInput(e.target.value.toUpperCase())}
                            placeholder="NH842K19"
                            className="w-full rounded-xl border border-[#C9E0D0] px-3.5 py-2.5 text-sm font-mono uppercase tracking-wider text-[#0F2A1E] focus:outline-none focus:ring-2 focus:ring-[#114B32]/20"
                          />
                        </div>
                      )}
                    </div>

                    {formError && (
                      <div className="rounded-xl border border-red-200 bg-red-50 px-3.5 py-2.5 text-xs text-red-700">
                        {formError}
                      </div>
                    )}

                    <button
                      type="submit"
                      disabled={submitting}
                      className="w-full py-3.5 px-5 rounded-2xl bg-[#114B32] text-white text-sm font-bold hover:bg-[#0D3B27] disabled:opacity-50 transition-colors flex items-center justify-center gap-2"
                    >
                      <span>
                        {submitting ? 'Đang khởi tạo không gian...' : 'Hoàn tất & Vào Nhiphoc'}
                      </span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </form>
                )}

                <div className="pt-5 mt-6 border-t border-[#E3EFE7] flex items-center justify-between text-xs text-[#527361]">
                  <span>Nhiphoc · Học tập nhịp nhàng</span>
                  <span>Đồng bộ Firebase Cloud</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Interactive 3-Role Visual Preview Section */}
        <section id="roles-preview" className="bg-white py-14 border-b border-[#D5E6DA]">
          <div className="max-w-[1320px] mx-auto px-6 space-y-8">
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
              <div className="max-w-xl">
                <p className="text-xs font-bold text-[#186A47]">Trải nghiệm theo từng vai trò</p>
                <h2 className="text-2xl sm:text-3xl font-extrabold text-[#0F2A1E] mt-1">
                  Ba không gian riêng biệt, chung một nhịp học
                </h2>
              </div>
              <p className="text-sm text-[#426352] max-w-md">
                Mỗi người dùng bước vào đúng giao diện tối ưu cho nhiệm vụ của mình, liên kết tức
                thì qua mã học sinh.
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Student Mini Preview */}
              <div className="rounded-2xl border border-[#CFE3D5] bg-[#F4FAF6] p-6 space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-[#114B32]">01 · Giao diện Học sinh</span>
                  <Trees className="w-4 h-4 text-[#186A47]" />
                </div>
                <h3 className="text-lg font-bold text-[#0F2A1E]">
                  Bài tập · Chụp ảnh · Cây tập trung
                </h3>
                <div className="rounded-xl border border-[#CFE3D5] bg-white p-4 space-y-3">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-[#114B32]">Toán học · Hôm nay</span>
                    <span className="inline-flex items-center gap-1 text-[#186A47] font-semibold">
                      <Check className="w-3.5 h-3.5" />
                      Đã nộp
                    </span>
                  </div>
                  <p className="text-sm font-bold text-[#0F2A1E]">
                    Giải 5 bài phương trình bậc nhất
                  </p>
                  <div className="flex items-center justify-between pt-2 border-t border-[#EAF4ED] text-xs text-[#426352]">
                    <span className="inline-flex items-center gap-1.5">
                      <Camera className="w-3.5 h-3.5 text-[#114B32]" />
                      Đã đính kèm ảnh vở
                    </span>
                    <span className="font-mono tabular-nums text-[#114B32]">25:00</span>
                  </div>
                </div>
              </div>

              {/* Parent Dark Mini Preview */}
              <div className="rounded-2xl border border-[#23372C] bg-[#0D1611] text-[#EFF6F2] p-6 space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-[#9AD9B0]">02 · Giao diện Cha mẹ (Tối)</span>
                  <HeartHandshake className="w-4 h-4 text-[#9AD9B0]" />
                </div>
                <h3 className="text-lg font-bold text-white">
                  Liên lạc · Tiến độ con · Trợ giúp
                </h3>
                <div className="rounded-xl border border-[#23372C] bg-[#14221B] p-4 space-y-3">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-[#9AB5A5]">Tiến độ hôm nay</span>
                    <span className="font-mono font-bold text-[#9AD9B0] tabular-nums">3/3 bài</span>
                  </div>
                  <p className="text-sm font-semibold text-[#EFF6F2]">
                    Con đã hoàn thành bài Toán & Tiếng Anh
                  </p>
                  <div className="flex items-center justify-between pt-2 border-t border-[#23372C] text-xs text-[#9AB5A5]">
                    <span>Cây tập trung: 95 phút</span>
                    <span className="text-[#9AD9B0] font-semibold">Đã chấm xong</span>
                  </div>
                </div>
              </div>

              {/* Assistant Mini Preview */}
              <div className="rounded-2xl border border-[#CFE3D5] bg-white p-6 space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-[#114B32]">03 · Giao diện Trợ lý</span>
                  <CheckCheck className="w-4 h-4 text-[#186A47]" />
                </div>
                <h3 className="text-lg font-bold text-[#0F2A1E]">
                  Học sinh · Chấm bài · Phản hồi
                </h3>
                <div className="rounded-xl border border-[#CFE3D5] bg-[#F7FBF8] p-4 space-y-3">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-[#114B32]">Trạng thái: Đang trực</span>
                    <span className="font-mono text-[#186A47] tabular-nums">4 bài chờ</span>
                  </div>
                  <p className="text-sm font-bold text-[#0F2A1E]">
                    Chấm ảnh bài làm & gửi nhận xét tức thì
                  </p>
                  <div className="flex items-center justify-between pt-2 border-t border-[#E3EFE7] text-xs text-[#426352]">
                    <span>Xác nhận lịch phụ huynh</span>
                    <span className="font-semibold text-[#114B32]">Đồng bộ trực tiếp</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Workflow Band */}
        <section id="workflow" className="bg-[#F3F8F4] py-12">
          <div className="max-w-[1320px] mx-auto px-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="p-6 rounded-2xl border border-[#CFE3D5] bg-white">
                <p className="text-xs font-mono font-bold text-[#186A47]">01</p>
                <h3 className="text-base font-bold text-[#0F2A1E] mt-2">
                  Chụp ảnh nộp bài & hai lần tick rõ ràng
                </h3>
                <p className="text-sm text-[#426352] mt-1.5 leading-relaxed">
                  Nộp xong ảnh là danh sách tick Đã nộp ngay; trợ lý kiểm tra xong sẽ chuyển thành
                  tick Đã chấm xong kèm điểm số.
                </p>
              </div>
              <div className="p-6 rounded-2xl border border-[#CFE3D5] bg-white">
                <p className="text-xs font-mono font-bold text-[#186A47]">02</p>
                <h3 className="text-base font-bold text-[#0F2A1E] mt-2">
                  Nhận xét ngay khi trực hoặc sau 1 giờ
                </h3>
                <p className="text-sm text-[#426352] mt-1.5 leading-relaxed">
                  Nếu trợ lý đang bật Đang trực, học sinh nhận phản hồi tiếp nhận ngay; nếu ngoại
                  tuyến, hệ thống đếm ngược 1 giờ tự động mở nhận xét.
                </p>
              </div>
              <div className="p-6 rounded-2xl border border-[#CFE3D5] bg-white">
                <p className="text-xs font-mono font-bold text-[#186A47]">03</p>
                <h3 className="text-base font-bold text-[#0F2A1E] mt-2">
                  Dữ liệu thật lưu trữ đa thiết bị
                </h3>
                <p className="text-sm text-[#426352] mt-1.5 leading-relaxed">
                  Mọi tài khoản đều đăng nhập lại được trên điện thoại hoặc máy tính khác mà vẫn
                  giữ nguyên lịch sử học tập.
                </p>
              </div>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
};
