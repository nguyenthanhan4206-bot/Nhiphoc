import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  collection,
  doc,
  onSnapshot,
  query,
  where,
} from 'firebase/firestore';
import {
  BookOpen,
  CalendarClock,
  Camera,
  CameraOff,
  Check,
  Clock,
  Coffee,
  Edit3,
  GraduationCap,
  Heart,
  HeartHandshake,
  ListChecks,
  LogOut,
  MessageSquareText,
  Mic,
  MicOff,
  Pause,
  Play,
  Plus,
  RefreshCw,
  Send,
  Sprout,
  Trash2,
  UserPlus,
  Users,
  Video,
} from 'lucide-react';
import { db, handleFirestoreError } from '../firebase';
import {
  OperationType,
  PublicUser,
  StudentProfile,
  StudyDateIceCandidate,
  StudyDateMessage,
  StudyDateNote,
  StudyDateRoom,
  StudyDateVibe,
  StudyFriend,
} from '../types';
import { logFocusSession } from '../services/nhiphocService';
import {
  addStudyDateNote,
  createStudyFriendFromRoom,
  deleteStudyDateNote,
  findOrCreateStudyDateRoom,
  getFriendPairIds,
  inviteBestFriendToStudyDate,
  joinWaitingStudyDateRoom,
  leaveOrEndStudyDateRoom,
  removeStudyFriend,
  sendStudyDateIceCandidate,
  sendStudyDateMessage,
  toggleStudyDateFriendRequest,
  toggleStudyDateNote,
  updateStudyDateGuestMedia,
  updateStudyDateHostMedia,
  updateStudyDateSharedTopic,
  updateStudyDateTimerState,
} from '../services/studyDateService';
import { formatTimeAgoVi } from '../utils/imageCompress';
import { MascotAvatar } from './MascotAvatar';

interface StudyWithMeDateViewProps {
  user: PublicUser;
  student: StudentProfile;
  onNotify?: (toast: {
    category: 'assignment' | 'graded' | 'message' | 'info';
    title: string;
    message: string;
  }) => void;
}

const ICE_SERVERS: RTCConfiguration = {
  iceServers: [
    { urls: 'stun:stun.l.google.com:19302' },
    { urls: 'stun:stun1.l.google.com:19302' },
  ],
};

const SUBJECT_PRESETS = [
  'Mọi môn học',
  'Giải tích / Toán cao cấp',
  'Tiếng Anh / IELTS',
  'Lập trình / CNTT',
  'Kinh tế / Tài chính',
  'Triết học / Đại cương',
  'Vật lý / Hóa học',
];

const VIBE_OPTIONS: Array<{
  id: StudyDateVibe;
  title: string;
  desc: string;
}> = [
  {
    id: 'silent_cam',
    title: 'Bật cam học im lặng',
    desc: 'Giữ hiện diện cùng nhau, tắt mic tập trung cao độ.',
  },
  {
    id: 'pomodoro_chat',
    title: 'Pomodoro + Trò chuyện 5p',
    desc: 'Tập trung theo nhịp 25–50p, làm quen vào giờ giải lao.',
  },
  {
    id: 'audio_lofi',
    title: 'Trao đổi nhẹ nhàng',
    desc: 'Có thể mở mic chia sẻ mục tiêu và động viên nhau.',
  },
];

const FOCUS_REACTIONS = [
  'Giữ nhịp tập trung nhé!',
  'Cùng hoàn thành mục tiêu hôm nay nào.',
  'Cố thêm chút nữa là xong phiên rồi!',
];

const BREAK_ICEBREAKERS = [
  'Ngành học của bạn kỳ này môn nào thử thách nhất?',
  'Đồ uống chân ái giúp bạn tỉnh táo khi chạy deadline là gì?',
  'Mục tiêu lớn nhất tuần này bạn đang cố gắng hoàn thành là gì?',
  'Bạn thường học hiệu quả nhất vào sáng sớm hay buổi tối?',
];

const STUDY_NOTE_TEMPLATES = [
  'Chốt phạm vi chương/đề thi cần ôn xong trong phiên này',
  'Tự làm 30 phút rồi cùng kiểm tra đáp án vào giờ giải lao',
  'Ghi chú lại câu khó để trao đổi nhanh 5 phút cuối giờ',
];

function getVibeLabel(vibe: StudyDateVibe): string {
  return VIBE_OPTIONS.find((v) => v.id === vibe)?.title || 'StudyWithMe Date';
}

function formatClock(totalSeconds: number): string {
  const safe = Math.max(0, Math.floor(totalSeconds));
  const mins = Math.floor(safe / 60);
  const secs = safe % 60;
  return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}

function normalizeSubject(val: string): string {
  return val.trim().toLowerCase().replace(/\s+/g, ' ');
}

export const StudyWithMeDateView: React.FC<StudyWithMeDateViewProps> = ({
  user,
  student,
  onNotify,
}) => {
  // Lobby profile form state
  const [displayName, setDisplayName] = useState(user.displayName || student.studentName);
  const [major, setMajor] = useState(() =>
    student.grade.toLowerCase().includes('sinh viên') || student.grade.toLowerCase().includes('đh')
      ? student.grade
      : 'Sinh viên Đại học · Công nghệ thông tin',
  );
  const [goal, setGoal] = useState('Hoàn thành đề cương & ôn tập bài giảng');
  const [selectedSubjectPreset, setSelectedSubjectPreset] = useState<string>('Mọi môn học');
  const [customSubject, setCustomSubject] = useState<string>('');
  const [strictSubjectMatch, setStrictSubjectMatch] = useState(false);
  const [lobbySubjectFilter, setLobbySubjectFilter] = useState<'all' | 'matching'>('all');

  const [vibe, setVibe] = useState<StudyDateVibe>('pomodoro_chat');
  const [durationMinutes, setDurationMinutes] = useState<number>(25);
  const [wantCam, setWantCam] = useState(false);
  const [wantMic, setWantMic] = useState(false);

  const effectiveSubject = useMemo(() => {
    if (selectedSubjectPreset === '__custom__') {
      return customSubject.trim() || 'Mọi môn học';
    }
    return selectedSubjectPreset;
  }, [customSubject, selectedSubjectPreset]);

  // Lobby rooms, friend invites, and best friends state
  const [waitingRooms, setWaitingRooms] = useState<StudyDateRoom[]>([]);
  const [friendInvites, setFriendInvites] = useState<StudyDateRoom[]>([]);
  const [studyFriends, setStudyFriends] = useState<StudyFriend[]>([]);
  const [confirmRemoveFriendId, setConfirmRemoveFriendId] = useState<string | null>(null);
  const [invitingFriendUid, setInvitingFriendUid] = useState<string | null>(null);

  // Active room state
  const [activeRoomId, setActiveRoomId] = useState<string | null>(null);
  const [activeRoom, setActiveRoom] = useState<StudyDateRoom | null>(null);
  const [roomMessages, setRoomMessages] = useState<StudyDateMessage[]>([]);
  const [roomNotes, setRoomNotes] = useState<StudyDateNote[]>([]);
  const [joining, setJoining] = useState(false);
  const [actionError, setActionError] = useState<string | null>(null);

  // Right panel tabs: 'study' (Cùng ôn 1 môn) vs 'chat' (Trò chuyện)
  const [rightTab, setRightTab] = useState<'study' | 'chat'>('study');
  const [editingTopic, setEditingTopic] = useState(false);
  const [topicSubjectInput, setTopicSubjectInput] = useState('');
  const [topicDetailInput, setTopicDetailInput] = useState('');
  const [savingTopic, setSavingTopic] = useState(false);
  const [noteInput, setNoteInput] = useState('');
  const [addingNote, setAddingNote] = useState(false);
  const [togglingFriend, setTogglingFriend] = useState(false);

  // Chat input + Focus Tree logging state
  const [chatInput, setChatInput] = useState('');
  const [sendingChat, setSendingChat] = useState(false);
  const [loggedFocusForRoomId, setLoggedFocusForRoomId] = useState<string | null>(null);
  const [savingTree, setSavingTree] = useState(false);

  // Media & WebRTC state
  const [localCamOn, setLocalCamOn] = useState(false);
  const [localMicOn, setLocalMicOn] = useState(false);
  const [mediaError, setMediaError] = useState<string | null>(null);
  const [rtcState, setRtcState] = useState<'idle' | 'connecting' | 'connected' | 'disconnected'>('idle');
  const [remoteHasVideo, setRemoteHasVideo] = useState(false);
  const [nowMs, setNowMs] = useState(() => Date.now());

  const localVideoRef = useRef<HTMLVideoElement | null>(null);
  const remoteVideoRef = useRef<HTMLVideoElement | null>(null);
  const chatEndRef = useRef<HTMLDivElement | null>(null);

  const localStreamRef = useRef<MediaStream | null>(null);
  const remoteStreamRef = useRef<MediaStream | null>(null);
  const pcRef = useRef<RTCPeerConnection | null>(null);
  const videoSenderRef = useRef<RTCRtpSender | null>(null);
  const audioSenderRef = useRef<RTCRtpSender | null>(null);
  const sentOfferRef = useRef(false);
  const appliedOfferRef = useRef(false);
  const appliedAnswerRef = useRef(false);
  const processedIceIdsRef = useRef<Set<string>>(new Set());
  const pendingIceQueueRef = useRef<RTCIceCandidateInit[]>([]);
  const prevRoomStatusRef = useRef<string | null>(null);
  const prevPartnerWantsFriendRef = useRef<boolean>(false);
  const notifiedInviteIdsRef = useRef<Set<string>>(new Set());
  const createdFriendRoomIdsRef = useRef<Set<string>>(new Set());

  // Tick timer display smoothly
  useEffect(() => {
    const id = setInterval(() => setNowMs(Date.now()), 500);
    return () => clearInterval(id);
  }, []);

  // Stop local media & close PeerConnection helper
  const teardownMediaAndRtc = useCallback(() => {
    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach((t) => t.stop());
      localStreamRef.current = null;
    }
    if (localVideoRef.current) {
      localVideoRef.current.srcObject = null;
    }
    if (remoteVideoRef.current) {
      remoteVideoRef.current.srcObject = null;
    }
    if (pcRef.current) {
      pcRef.current.close();
      pcRef.current = null;
    }
    videoSenderRef.current = null;
    audioSenderRef.current = null;
    remoteStreamRef.current = null;
    sentOfferRef.current = false;
    appliedOfferRef.current = false;
    appliedAnswerRef.current = false;
    processedIceIdsRef.current.clear();
    pendingIceQueueRef.current = [];
    setLocalCamOn(false);
    setLocalMicOn(false);
    setRemoteHasVideo(false);
    setRtcState('idle');
  }, []);

  useEffect(() => {
    return () => {
      teardownMediaAndRtc();
    };
  }, [teardownMediaAndRtc]);

  // Listen to Best Friends list (two queries: uidA == uid and uidB == uid)
  useEffect(() => {
    let listA: StudyFriend[] = [];
    let listB: StudyFriend[] = [];

    const mergeAndSet = () => {
      const merged = [...listA, ...listB];
      const byId = new Map<string, StudyFriend>();
      for (const item of merged) {
        byId.set(item.id, item);
      }
      const sorted = Array.from(byId.values()).sort(
        (a, b) => (b.createdAt?.toMillis?.() || 0) - (a.createdAt?.toMillis?.() || 0),
      );
      setStudyFriends(sorted);
    };

    const qA = query(collection(db, 'study_friends'), where('uidA', '==', user.uid));
    const qB = query(collection(db, 'study_friends'), where('uidB', '==', user.uid));

    const unsubA = onSnapshot(
      qA,
      (snap) => {
        listA = snap.docs.map((d) => d.data() as StudyFriend);
        mergeAndSet();
      },
      (error) => handleFirestoreError(error, OperationType.LIST, 'study_friends'),
    );

    const unsubB = onSnapshot(
      qB,
      (snap) => {
        listB = snap.docs.map((d) => d.data() as StudyFriend);
        mergeAndSet();
      },
      (error) => handleFirestoreError(error, OperationType.LIST, 'study_friends'),
    );

    return () => {
      unsubA();
      unsubB();
    };
  }, [user.uid]);

  // Listen to public waiting rooms when in Lobby (MUST filter invitedFriendUid == '' per rules)
  useEffect(() => {
    if (activeRoomId) return;

    const q = query(
      collection(db, 'study_date_rooms'),
      where('status', '==', 'waiting'),
      where('invitedFriendUid', '==', ''),
    );
    const unsub = onSnapshot(
      q,
      (snap) => {
        const cutoffMs = Date.now() - 30 * 60 * 1000;
        const list = snap.docs
          .map((d) => d.data() as StudyDateRoom)
          .filter((r) => {
            if (r.hostUid === user.uid || r.guestUid !== '') return false;
            const created = r.createdAt?.toMillis?.() || Date.now();
            return created >= cutoffMs;
          })
          .sort((a, b) => (b.createdAt?.toMillis?.() || 0) - (a.createdAt?.toMillis?.() || 0));
        setWaitingRooms(list);
      },
      (error) => handleFirestoreError(error, OperationType.LIST, 'study_date_rooms'),
    );
    return () => unsub();
  }, [activeRoomId, user.uid]);

  // Listen to private best-friend re-meet invitations directed to current user
  useEffect(() => {
    const qInv = query(
      collection(db, 'study_date_rooms'),
      where('status', '==', 'waiting'),
      where('invitedFriendUid', '==', user.uid),
    );
    const unsub = onSnapshot(
      qInv,
      (snap) => {
        const cutoffMs = Date.now() - 30 * 60 * 1000;
        const list = snap.docs
          .map((d) => d.data() as StudyDateRoom)
          .filter((r) => {
            if (r.guestUid !== '' || r.hostUid === user.uid) return false;
            const created = r.createdAt?.toMillis?.() || Date.now();
            return created >= cutoffMs;
          })
          .sort((a, b) => (b.createdAt?.toMillis?.() || 0) - (a.createdAt?.toMillis?.() || 0));

        list.forEach((inv) => {
          if (!notifiedInviteIdsRef.current.has(inv.id)) {
            notifiedInviteIdsRef.current.add(inv.id);
            onNotify?.({
              category: 'message',
              title: 'Lời mời Hẹn học lại từ Bạn thân!',
              message: `${inv.hostName} đang chờ bạn cùng ôn môn ${inv.subject || 'chung'}.`,
            });
          }
        });
        setFriendInvites(list);
      },
      (error) => handleFirestoreError(error, OperationType.LIST, 'study_date_rooms'),
    );
    return () => unsub();
  }, [onNotify, user.uid]);

  // Listen to active StudyWithMe Date room document
  useEffect(() => {
    if (!activeRoomId) {
      setActiveRoom(null);
      prevRoomStatusRef.current = null;
      prevPartnerWantsFriendRef.current = false;
      return;
    }

    const roomPath = `study_date_rooms/${activeRoomId}`;
    const unsub = onSnapshot(
      doc(db, 'study_date_rooms', activeRoomId),
      (snap) => {
        if (!snap.exists()) {
          setActiveRoom(null);
          setActiveRoomId(null);
          teardownMediaAndRtc();
          return;
        }
        const room = snap.data() as StudyDateRoom;
        setActiveRoom(room);

        if (
          prevRoomStatusRef.current === 'waiting' &&
          (room.status === 'matched' || room.status === 'active')
        ) {
          onNotify?.({
            category: 'info',
            title: 'Đã ghép đôi StudyWithMe Date!',
            message: `${room.guestName} (${room.guestMajor}) vừa vào học cùng bạn.`,
          });
        }
        prevRoomStatusRef.current = room.status;

        const isRoomHost = room.hostUid === user.uid;
        const partnerWants = isRoomHost ? room.guestWantsFriend : room.hostWantsFriend;
        const iWant = isRoomHost ? room.hostWantsFriend : room.guestWantsFriend;
        if (partnerWants && !prevPartnerWantsFriendRef.current && !iWant) {
          const pName = isRoomHost ? room.guestName : room.hostName;
          onNotify?.({
            category: 'info',
            title: 'Lời mời Kết bạn thân!',
            message: `${pName || 'Bạn học'} muốn thêm bạn làm Bạn thân để hẹn học lại.`,
          });
        }
        prevPartnerWantsFriendRef.current = partnerWants;
      },
      (error) => handleFirestoreError(error, OperationType.GET, roomPath),
    );
    return () => unsub();
  }, [activeRoomId, onNotify, teardownMediaAndRtc, user.uid]);

  // Auto-persist study_friends record once BOTH hostWantsFriend & guestWantsFriend are true
  useEffect(() => {
    if (!activeRoom || !activeRoom.guestUid) return;
    if (!activeRoom.hostWantsFriend || !activeRoom.guestWantsFriend) return;
    if (createdFriendRoomIdsRef.current.has(activeRoom.id)) return;

    const { pairId } = getFriendPairIds(activeRoom.hostUid, activeRoom.guestUid);
    const alreadyExists = studyFriends.some((f) => f.id === pairId);
    createdFriendRoomIdsRef.current.add(activeRoom.id);

    if (alreadyExists) return;

    createStudyFriendFromRoom(activeRoom, user.uid).then((created) => {
      if (created || !alreadyExists) {
        const partnerName = activeRoom.hostUid === user.uid ? activeRoom.guestName : activeRoom.hostName;
        onNotify?.({
          category: 'graded',
          title: 'Đã trở thành Bạn thân StudyWithMe!',
          message: `Bạn và ${partnerName} có thể hẹn học lại bất cứ lúc nào từ sảnh chờ.`,
        });
      }
    });
  }, [activeRoom, onNotify, studyFriends, user.uid]);

  // Listen to room chat messages
  useEffect(() => {
    if (!activeRoomId) {
      setRoomMessages([]);
      return;
    }

    const msgPath = `study_date_rooms/${activeRoomId}/messages`;
    const unsub = onSnapshot(
      collection(db, 'study_date_rooms', activeRoomId, 'messages'),
      (snap) => {
        const list = snap.docs.map((d) => d.data() as StudyDateMessage);
        list.sort((a, b) => (a.createdAt?.toMillis?.() || 0) - (b.createdAt?.toMillis?.() || 0));
        setRoomMessages(list);
      },
      (error) => handleFirestoreError(error, OperationType.LIST, msgPath),
    );
    return () => unsub();
  }, [activeRoomId]);

  // Listen to shared revision notes / checklist (Cùng ôn 1 môn)
  useEffect(() => {
    if (!activeRoomId) {
      setRoomNotes([]);
      return;
    }

    const notesPath = `study_date_rooms/${activeRoomId}/study_notes`;
    const unsub = onSnapshot(
      collection(db, 'study_date_rooms', activeRoomId, 'study_notes'),
      (snap) => {
        const list = snap.docs.map((d) => d.data() as StudyDateNote);
        list.sort((a, b) => (a.createdAt?.toMillis?.() || 0) - (b.createdAt?.toMillis?.() || 0));
        setRoomNotes(list);
      },
      (error) => handleFirestoreError(error, OperationType.LIST, notesPath),
    );
    return () => unsub();
  }, [activeRoomId]);

  useEffect(() => {
    if (rightTab === 'chat') {
      chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [rightTab, roomMessages.length]);

  // Acquire or update local camera / mic tracks safely
  const syncLocalTracks = useCallback(
    async (enableCam: boolean, enableMic: boolean) => {
      setMediaError(null);
      let stream = localStreamRef.current;

      if (!enableCam && !enableMic) {
        if (stream) {
          stream.getTracks().forEach((t) => t.stop());
          localStreamRef.current = null;
        }
        if (localVideoRef.current) {
          localVideoRef.current.srcObject = null;
        }
        await videoSenderRef.current?.replaceTrack(null).catch(() => {});
        await audioSenderRef.current?.replaceTrack(null).catch(() => {});
        setLocalCamOn(false);
        setLocalMicOn(false);
        return { cam: false, mic: false };
      }

      if (!navigator.mediaDevices?.getUserMedia) {
        setMediaError('Trình duyệt hiện tại không hỗ trợ Camera/Micro. Bạn vẫn có thể học chế độ không cam.');
        return { cam: false, mic: false };
      }

      let finalCam = enableCam;
      let finalMic = enableMic;

      try {
        if (!stream) {
          stream = new MediaStream();
          localStreamRef.current = stream;
        }

        const existingVideo = stream.getVideoTracks()[0];
        if (enableCam && (!existingVideo || existingVideo.readyState === 'ended')) {
          const camStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
          const track = camStream.getVideoTracks()[0];
          if (track) stream.addTrack(track);
        } else if (!enableCam && existingVideo) {
          existingVideo.stop();
          stream.removeTrack(existingVideo);
        }

        const existingAudio = stream.getAudioTracks()[0];
        if (enableMic && (!existingAudio || existingAudio.readyState === 'ended')) {
          const micStream = await navigator.mediaDevices.getUserMedia({ video: false, audio: true });
          const track = micStream.getAudioTracks()[0];
          if (track) stream.addTrack(track);
        } else if (!enableMic && existingAudio) {
          existingAudio.stop();
          stream.removeTrack(existingAudio);
        }
      } catch {
        setMediaError(
          'Không thể truy cập Camera/Micro (hoặc quyền bị từ chối). Đã chuyển sang chế độ học không cam.',
        );
        finalCam = Boolean(localStreamRef.current?.getVideoTracks().some((t) => t.readyState === 'live'));
        finalMic = Boolean(localStreamRef.current?.getAudioTracks().some((t) => t.readyState === 'live'));
      }

      const activeVideoTrack = localStreamRef.current?.getVideoTracks()[0] || null;
      const activeAudioTrack = localStreamRef.current?.getAudioTracks()[0] || null;

      if (localVideoRef.current) {
        localVideoRef.current.srcObject = activeVideoTrack ? localStreamRef.current : null;
      }

      if (videoSenderRef.current) {
        await videoSenderRef.current.replaceTrack(activeVideoTrack).catch(() => {});
      }
      if (audioSenderRef.current) {
        await audioSenderRef.current.replaceTrack(activeAudioTrack).catch(() => {});
      }

      finalCam = Boolean(activeVideoTrack);
      finalMic = Boolean(activeAudioTrack);
      setLocalCamOn(finalCam);
      setLocalMicOn(finalMic);
      return { cam: finalCam, mic: finalMic };
    },
    [],
  );

  // Rebind local video element whenever DOM switches between Lobby -> Waiting -> Active
  useEffect(() => {
    if (localVideoRef.current && localCamOn && localStreamRef.current) {
      localVideoRef.current.srcObject = localStreamRef.current;
    }
  }, [activeRoom?.status, localCamOn]);

  // WebRTC PeerConnection & Firestore SDP + ICE Signaling
  const isHost = Boolean(activeRoom && activeRoom.hostUid === user.uid);
  const isMatchedOrActive = Boolean(
    activeRoom && (activeRoom.status === 'matched' || activeRoom.status === 'active') && activeRoom.guestUid,
  );

  useEffect(() => {
    if (!activeRoom || !isMatchedOrActive) return;

    const roomId = activeRoom.id;
    let pc = pcRef.current;

    if (!pc) {
      pc = new RTCPeerConnection(ICE_SERVERS);
      pcRef.current = pc;
      setRtcState('connecting');

      const remoteStream = new MediaStream();
      remoteStreamRef.current = remoteStream;
      if (remoteVideoRef.current) {
        remoteVideoRef.current.srcObject = remoteStream;
      }

      pc.ontrack = (event) => {
        const target = remoteStreamRef.current || new MediaStream();
        remoteStreamRef.current = target;
        event.streams[0]?.getTracks().forEach((track) => {
          if (!target.getTracks().some((t) => t.id === track.id)) {
            target.addTrack(track);
          }
        });
        if (!target.getTracks().some((t) => t.id === event.track.id)) {
          target.addTrack(event.track);
        }
        if (remoteVideoRef.current) {
          remoteVideoRef.current.srcObject = target;
        }
        if (event.track.kind === 'video') {
          setRemoteHasVideo(true);
        }
      };

      pc.onconnectionstatechange = () => {
        if (!pc) return;
        if (pc.connectionState === 'connected') {
          setRtcState('connected');
        } else if (
          pc.connectionState === 'failed' ||
          pc.connectionState === 'disconnected' ||
          pc.connectionState === 'closed'
        ) {
          setRtcState('disconnected');
        }
      };

      pc.onicecandidate = (event) => {
        if (event.candidate) {
          sendStudyDateIceCandidate({
            room: activeRoom,
            senderUid: user.uid,
            candidate: event.candidate.toJSON(),
          });
        }
      };

      if (isHost) {
        const vTrans = pc.addTransceiver('video', { direction: 'sendrecv' });
        const aTrans = pc.addTransceiver('audio', { direction: 'sendrecv' });
        videoSenderRef.current = vTrans.sender;
        audioSenderRef.current = aTrans.sender;

        const localVid = localStreamRef.current?.getVideoTracks()[0] || null;
        const localAud = localStreamRef.current?.getAudioTracks()[0] || null;
        if (localVid) vTrans.sender.replaceTrack(localVid).catch(() => {});
        if (localAud) aTrans.sender.replaceTrack(localAud).catch(() => {});
      }
    }

    // Host creates and publishes Offer once matched
    if (isHost && !sentOfferRef.current && !activeRoom.offerSdp) {
      sentOfferRef.current = true;
      pc.createOffer()
        .then(async (offer) => {
          await pc!.setLocalDescription(offer);
          if (offer.sdp) {
            await updateStudyDateHostMedia(roomId, { offerSdp: offer.sdp.slice(0, 16000) });
          }
        })
        .catch((err) => console.warn('WebRTC offer creation failed:', err));
    }

    // Guest receives Offer, binds transceivers, and publishes Answer
    if (!isHost && activeRoom.offerSdp && !appliedOfferRef.current) {
      appliedOfferRef.current = true;
      pc.setRemoteDescription({ type: 'offer', sdp: activeRoom.offerSdp })
        .then(async () => {
          const transceivers = pc!.getTransceivers();
          for (const t of transceivers) {
            if (t.receiver.track?.kind === 'video') {
              t.direction = 'sendrecv';
              videoSenderRef.current = t.sender;
              const localVid = localStreamRef.current?.getVideoTracks()[0] || null;
              if (localVid) await t.sender.replaceTrack(localVid).catch(() => {});
            } else if (t.receiver.track?.kind === 'audio') {
              t.direction = 'sendrecv';
              audioSenderRef.current = t.sender;
              const localAud = localStreamRef.current?.getAudioTracks()[0] || null;
              if (localAud) await t.sender.replaceTrack(localAud).catch(() => {});
            }
          }

          for (const queued of pendingIceQueueRef.current) {
            await pc!.addIceCandidate(queued).catch(() => {});
          }
          pendingIceQueueRef.current = [];

          const answer = await pc!.createAnswer();
          await pc!.setLocalDescription(answer);
          if (answer.sdp) {
            await updateStudyDateGuestMedia(roomId, { answerSdp: answer.sdp.slice(0, 16000) });
          }
        })
        .catch((err) => console.warn('WebRTC offer handling failed:', err));
    }

    // Host receives Answer
    if (isHost && activeRoom.answerSdp && !appliedAnswerRef.current && pc.localDescription) {
      appliedAnswerRef.current = true;
      pc.setRemoteDescription({ type: 'answer', sdp: activeRoom.answerSdp })
        .then(async () => {
          for (const queued of pendingIceQueueRef.current) {
            await pc!.addIceCandidate(queued).catch(() => {});
          }
          pendingIceQueueRef.current = [];
        })
        .catch((err) => console.warn('WebRTC answer handling failed:', err));
    }
  }, [activeRoom, isHost, isMatchedOrActive, user.uid]);

  // Listen to WebRTC ICE candidates subcollection
  useEffect(() => {
    if (!activeRoomId || !isMatchedOrActive) return;

    const icePath = `study_date_rooms/${activeRoomId}/ice_candidates`;
    const unsub = onSnapshot(
      collection(db, 'study_date_rooms', activeRoomId, 'ice_candidates'),
      (snap) => {
        snap.docs.forEach((d) => {
          const cand = d.data() as StudyDateIceCandidate;
          if (cand.senderUid === user.uid || processedIceIdsRef.current.has(cand.id)) {
            return;
          }
          processedIceIdsRef.current.add(cand.id);
          const init: RTCIceCandidateInit = {
            candidate: cand.candidate,
            sdpMid: cand.sdpMid || null,
            sdpMLineIndex: cand.sdpMLineIndex,
          };
          const pc = pcRef.current;
          if (pc && pc.remoteDescription) {
            pc.addIceCandidate(init).catch(() => {});
          } else {
            pendingIceQueueRef.current.push(init);
          }
        });
      },
      (error) => handleFirestoreError(error, OperationType.LIST, icePath),
    );
    return () => unsub();
  }, [activeRoomId, isMatchedOrActive, user.uid]);

  // Re-attach remote stream when video element mounts
  useEffect(() => {
    if (remoteVideoRef.current && remoteStreamRef.current) {
      remoteVideoRef.current.srcObject = remoteStreamRef.current;
    }
  }, [remoteHasVideo, activeRoom?.hostCamOn, activeRoom?.guestCamOn]);

  const handleToggleLobbyCam = async () => {
    const next = !wantCam;
    const res = await syncLocalTracks(next, wantMic);
    setWantCam(res.cam);
  };

  const handleToggleLobbyMic = async () => {
    const next = !wantMic;
    const res = await syncLocalTracks(wantCam, next);
    setWantMic(res.mic);
  };

  const handleFindRandomMatch = async () => {
    setActionError(null);
    setJoining(true);
    try {
      const { roomId } = await findOrCreateStudyDateRoom({
        uid: user.uid,
        name: displayName,
        major,
        goal,
        subject: effectiveSubject,
        strictSubjectMatch,
        vibe,
        durationMinutes,
        camOn: localCamOn,
        micOn: localMicOn,
      });
      setActiveRoomId(roomId);
      setLoggedFocusForRoomId(null);
      setEditingTopic(false);
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'Không thể ghép phòng lúc này.');
    } finally {
      setJoining(false);
    }
  };

  const handleJoinSpecificRoom = async (roomId: string) => {
    setActionError(null);
    setJoining(true);
    try {
      const ok = await joinWaitingStudyDateRoom(roomId, {
        uid: user.uid,
        name: displayName,
        major,
        goal,
        subject: effectiveSubject,
        vibe,
        durationMinutes,
        camOn: localCamOn,
        micOn: localMicOn,
      });
      if (!ok) {
        setActionError('Phòng này vừa có bạn khác ghép đôi trước đó hoặc đã đóng. Hãy thử phòng khác nhé.');
        return;
      }
      setActiveRoomId(roomId);
      setLoggedFocusForRoomId(null);
      setEditingTopic(false);
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'Không thể tham gia phòng.');
    } finally {
      setJoining(false);
    }
  };

  const handleInviteFriend = async (friend: StudyFriend) => {
    const friendUid = friend.uidA === user.uid ? friend.uidB : friend.uidA;
    const friendName = friend.uidA === user.uid ? friend.nameB : friend.nameA;
    const chosenSubject =
      normalizeSubject(effectiveSubject) !== 'mọi môn học'
        ? effectiveSubject
        : friend.commonSubject || 'Mọi môn học';

    setActionError(null);
    setInvitingFriendUid(friendUid);
    try {
      const roomId = await inviteBestFriendToStudyDate(
        {
          uid: user.uid,
          name: displayName,
          major,
          goal: `Hẹn học lại cùng ${friendName}`,
          subject: chosenSubject,
          vibe,
          durationMinutes,
          camOn: localCamOn,
          micOn: localMicOn,
        },
        friendUid,
      );
      setActiveRoomId(roomId);
      setLoggedFocusForRoomId(null);
      setEditingTopic(false);
      onNotify?.({
        category: 'info',
        title: `Đã gửi lời mời tới ${friendName}`,
        message: 'Phòng học riêng đã sẵn sàng, đang đợi bạn thân của bạn tham gia.',
      });
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'Không thể tạo lời mời hẹn học lại.');
    } finally {
      setInvitingFriendUid(null);
    }
  };

  const handleRemoveFriend = async (friendPairId: string) => {
    try {
      await removeStudyFriend(friendPairId);
      setConfirmRemoveFriendId(null);
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'Không thể hủy kết bạn lúc này.');
    }
  };

  const handleLeaveRoom = async (rematchAfter = false) => {
    const roomToClose = activeRoom;
    setActiveRoomId(null);
    setActiveRoom(null);
    teardownMediaAndRtc();
    if (roomToClose) {
      await leaveOrEndStudyDateRoom(roomToClose, user.uid);
    }
    if (rematchAfter) {
      await handleFindRandomMatch();
    }
  };

  const handleToggleRoomCam = async () => {
    if (!activeRoom) return;
    const res = await syncLocalTracks(!localCamOn, localMicOn);
    if (isHost) {
      await updateStudyDateHostMedia(activeRoom.id, { hostCamOn: res.cam, hostMicOn: res.mic });
    } else {
      await updateStudyDateGuestMedia(activeRoom.id, { guestCamOn: res.cam, guestMicOn: res.mic });
    }
  };

  const handleToggleRoomMic = async () => {
    if (!activeRoom) return;
    const res = await syncLocalTracks(localCamOn, !localMicOn);
    if (isHost) {
      await updateStudyDateHostMedia(activeRoom.id, { hostCamOn: res.cam, hostMicOn: res.mic });
    } else {
      await updateStudyDateGuestMedia(activeRoom.id, { guestCamOn: res.cam, guestMicOn: res.mic });
    }
  };

  const handleToggleReady = async () => {
    if (!activeRoom) return;
    if (isHost) {
      await updateStudyDateHostMedia(activeRoom.id, { hostReady: !activeRoom.hostReady });
    } else {
      await updateStudyDateGuestMedia(activeRoom.id, { guestReady: !activeRoom.guestReady });
    }
  };

  const handleToggleBestFriend = async () => {
    if (!activeRoom || !activeRoom.guestUid || togglingFriend) return;
    const iWant = isHost ? activeRoom.hostWantsFriend : activeRoom.guestWantsFriend;
    setTogglingFriend(true);
    try {
      await toggleStudyDateFriendRequest(activeRoom, user.uid, !iWant);
    } finally {
      setTogglingFriend(false);
    }
  };

  const handleStartEditTopic = () => {
    if (!activeRoom) return;
    setTopicSubjectInput(activeRoom.subject || 'Mọi môn học');
    setTopicDetailInput(activeRoom.sharedTopic || '');
    setEditingTopic(true);
  };

  const handleSaveSharedTopic = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeRoom || activeRoom.status === 'ended') return;
    setSavingTopic(true);
    try {
      await updateStudyDateSharedTopic(activeRoom.id, {
        subject: topicSubjectInput,
        sharedTopic: topicDetailInput,
      });
      setEditingTopic(false);
    } finally {
      setSavingTopic(false);
    }
  };

  const handleAddNote = async (textOverride?: string) => {
    if (!activeRoom || activeRoom.status === 'ended') return;
    const content = (textOverride ?? noteInput).trim();
    if (!content) return;
    setAddingNote(true);
    try {
      await addStudyDateNote({
        room: activeRoom,
        createdBy: user.uid,
        authorName: displayName,
        content,
      });
      if (!textOverride) {
        setNoteInput('');
      }
    } finally {
      setAddingNote(false);
    }
  };

  const displaySecondsLeft = useMemo(() => {
    if (!activeRoom) return durationMinutes * 60;
    if (activeRoom.timerRunning && activeRoom.timerEndAtMs > 0) {
      return Math.max(0, Math.ceil((activeRoom.timerEndAtMs - nowMs) / 1000));
    }
    return activeRoom.remainingSeconds;
  }, [activeRoom, durationMinutes, nowMs]);

  const handleToggleTimer = async () => {
    if (!activeRoom || activeRoom.status === 'ended') return;
    if (activeRoom.timerRunning) {
      await updateStudyDateTimerState(activeRoom.id, {
        status: 'active',
        phase: activeRoom.phase,
        timerRunning: false,
        timerEndAtMs: 0,
        remainingSeconds: Math.max(0, displaySecondsLeft),
      });
    } else {
      const secs =
        displaySecondsLeft > 0
          ? displaySecondsLeft
          : activeRoom.phase === 'break'
            ? 5 * 60
            : activeRoom.durationMinutes * 60;
      await updateStudyDateTimerState(activeRoom.id, {
        status: 'active',
        phase: activeRoom.phase,
        timerRunning: true,
        timerEndAtMs: Date.now() + secs * 1000,
        remainingSeconds: secs,
      });
    }
  };

  const handleSwitchPhase = async (nextPhase: 'focus' | 'break') => {
    if (!activeRoom || activeRoom.status === 'ended') return;
    const secs = nextPhase === 'break' ? 5 * 60 : activeRoom.durationMinutes * 60;
    await updateStudyDateTimerState(activeRoom.id, {
      status: 'active',
      phase: nextPhase,
      timerRunning: true,
      timerEndAtMs: Date.now() + secs * 1000,
      remainingSeconds: secs,
    });
  };

  const handleLogDateToFocusTree = async () => {
    if (!activeRoom || loggedFocusForRoomId === activeRoom.id) return;
    const totalRoomSecs = activeRoom.durationMinutes * 60;
    const elapsedSecs =
      activeRoom.phase === 'focus' ? Math.max(0, totalRoomSecs - displaySecondsLeft) : totalRoomSecs;
    const minsToSave = Math.max(1, Math.min(180, Math.round(elapsedSecs / 60) || activeRoom.durationMinutes));
    const partnerName = isHost ? activeRoom.guestName : activeRoom.hostName;

    setSavingTree(true);
    try {
      await logFocusSession({
        student,
        uid: user.uid,
        durationMinutes: minsToSave,
        note: `StudyWithMe Date (${activeRoom.subject || 'Tự học'}) cùng ${partnerName || 'bạn mới'}`,
      });
      setLoggedFocusForRoomId(activeRoom.id);
      onNotify?.({
        category: 'info',
        title: 'Đã tưới Cây tập trung!',
        message: `Ghi nhận +${minsToSave} phút học StudyWithMe Date vào cây của bạn.`,
      });
    } finally {
      setSavingTree(false);
    }
  };

  const handleSendChat = async (textOverride?: string, kind: 'chat' | 'reaction' | 'checkin' = 'chat') => {
    if (!activeRoom || activeRoom.status === 'ended') return;
    const content = (textOverride ?? chatInput).trim();
    if (!content) return;
    setSendingChat(true);
    try {
      await sendStudyDateMessage({
        room: activeRoom,
        senderUid: user.uid,
        senderName: displayName,
        kind,
        content,
      });
      if (!textOverride) {
        setChatInput('');
      }
    } finally {
      setSendingChat(false);
    }
  };

  const visibleWaitingRooms = useMemo(() => {
    if (lobbySubjectFilter === 'all') return waitingRooms;
    const target = normalizeSubject(effectiveSubject);
    if (!target || target === 'mọi môn học') return waitingRooms;
    return waitingRooms.filter((r) => normalizeSubject(r.subject || '') === target);
  }, [effectiveSubject, lobbySubjectFilter, waitingRooms]);

  // --- VIEW 1: ACTIVE / WAITING / ENDED STUDY DATE ROOM ---
  if (activeRoom) {
    if (activeRoom.status === 'waiting') {
      const invitedFriend = activeRoom.invitedFriendUid
        ? studyFriends.find(
            (f) => f.uidA === activeRoom.invitedFriendUid || f.uidB === activeRoom.invitedFriendUid,
          )
        : undefined;
      const invitedName = invitedFriend
        ? invitedFriend.uidA === user.uid
          ? invitedFriend.nameB
          : invitedFriend.nameA
        : '';

      return (
        <div className="rounded-2xl border border-[#DCE8DF] bg-white p-6 sm:p-8 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-[#E5EFE8]">
            <div className="flex items-center gap-3.5">
              <MascotAvatar size="md" />
              <div>
                <h2 className="text-lg font-bold text-[#112A1E]">
                  {activeRoom.invitedFriendUid
                    ? `Đang chờ bạn thân ${invitedName || 'của bạn'} vào bàn học`
                    : 'Đang mở phòng chờ StudyWithMe Date'}
                </h2>
                <p className="text-xs text-[#4B6859] mt-0.5">
                  {activeRoom.invitedFriendUid
                    ? 'Lời mời riêng đã được gửi tới sảnh chờ của bạn thân. Phòng tự bắt đầu ngay khi bạn ấy tham gia.'
                    : 'Ngay khi có một sinh viên khác chọn ghép đôi, phòng học sẽ tự động bắt đầu.'}
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => handleLeaveRoom(false)}
              className="inline-flex items-center justify-center gap-2 px-4 py-2 rounded-xl border border-[#D4E3D8] text-xs font-semibold text-[#314E3F] hover:bg-[#EDF5EF] whitespace-nowrap shrink-0"
            >
              <LogOut className="w-3.5 h-3.5" />
              {activeRoom.invitedFriendUid ? 'Hủy lời mời' : 'Hủy tìm kiếm'}
            </button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
            <div className="lg:col-span-5 rounded-2xl bg-[#112A1E] text-white overflow-hidden aspect-video relative flex items-center justify-center">
              {localCamOn ? (
                <video
                  ref={localVideoRef}
                  autoPlay
                  muted
                  playsInline
                  className="w-full h-full object-cover scale-x-[-1]"
                />
              ) : (
                <div className="text-center p-6 space-y-2">
                  <GraduationCap className="w-8 h-8 text-[#A7D7B8] mx-auto" />
                  <p className="text-sm font-bold">{activeRoom.hostName}</p>
                  <p className="text-xs text-[#CBEAD4]">Camera đang tắt (có thể bật bất cứ lúc nào)</p>
                </div>
              )}
              <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between gap-2">
                <span className="text-xs font-medium text-white/90 bg-black/55 px-2.5 py-1 rounded-lg truncate">
                  {activeRoom.hostMajor}
                </span>
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={handleToggleRoomCam}
                    className="p-2 rounded-lg bg-black/60 text-white hover:bg-black/80"
                    aria-label="Bật hoặc tắt camera"
                  >
                    {localCamOn ? <Camera className="w-4 h-4" /> : <CameraOff className="w-4 h-4" />}
                  </button>
                  <button
                    type="button"
                    onClick={handleToggleRoomMic}
                    className="p-2 rounded-lg bg-black/60 text-white hover:bg-black/80"
                    aria-label="Bật hoặc tắt micro"
                  >
                    {localMicOn ? <Mic className="w-4 h-4" /> : <MicOff className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            </div>

            <div className="lg:col-span-7 flex flex-col justify-between rounded-2xl border border-[#DCE8DF] bg-[#F8FCF9] p-6 space-y-4">
              <div className="space-y-3">
                <p className="text-xs font-semibold text-[#165B3D]">
                  Thông tin thẻ ghép đôi của bạn · Môn ôn: {activeRoom.subject || 'Mọi môn học'}
                </p>
                <h3 className="text-xl font-bold text-[#112A1E]">{activeRoom.hostGoal}</h3>
                <div className="flex flex-wrap items-center gap-2 text-xs text-[#4B6859]">
                  <span>{activeRoom.hostName}</span>
                  <span aria-hidden="true">·</span>
                  <span>{activeRoom.hostMajor}</span>
                  <span aria-hidden="true">·</span>
                  <span>{getVibeLabel(activeRoom.vibe)}</span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono tabular-nums">{activeRoom.durationMinutes} phút</span>
                </div>
              </div>

              {mediaError && (
                <p className="text-xs text-amber-800 bg-amber-50 border border-amber-200 rounded-xl px-3.5 py-2.5">
                  {mediaError}
                </p>
              )}

              <div className="pt-4 border-t border-[#DCE8DF] flex flex-wrap items-center justify-between gap-3">
                <p className="text-xs text-[#4B6859]">
                  {activeRoom.invitedFriendUid
                    ? 'Chỉ bạn thân được mời mới thấy phòng riêng tư này.'
                    : 'Mẹo: Bạn có thể mở một tab khác với tài khoản thứ 2 để kiểm thử ghép đôi trực tiếp.'}
                </p>
              </div>
            </div>
          </div>
        </div>
      );
    }

    const partnerUid = isHost ? activeRoom.guestUid : activeRoom.hostUid;
    const partnerName = isHost ? activeRoom.guestName : activeRoom.hostName;
    const iWantFriend = isHost ? activeRoom.hostWantsFriend : activeRoom.guestWantsFriend;
    const partnerWantsFriend = isHost ? activeRoom.guestWantsFriend : activeRoom.hostWantsFriend;
    const pairIdIfMatched = partnerUid ? getFriendPairIds(user.uid, partnerUid).pairId : '';
    const isBestFriendNow = Boolean(
      (iWantFriend && partnerWantsFriend) ||
        (pairIdIfMatched && studyFriends.some((f) => f.id === pairIdIfMatched)),
    );

    if (activeRoom.status === 'ended') {
      const alreadyLogged = loggedFocusForRoomId === activeRoom.id;
      return (
        <div className="rounded-2xl border border-[#DCE8DF] bg-white p-8 text-center space-y-6">
          <MascotAvatar size="lg" className="mx-auto" />
          <div className="space-y-1.5 max-w-md mx-auto">
            <h2 className="text-xl font-bold text-[#112A1E]">
              Phiên StudyWithMe Date đã kết thúc
            </h2>
            <p className="text-sm text-[#4B6859]">
              Cảm ơn bạn đã giữ nhịp học tập ({activeRoom.subject || 'Tự học'}) cùng{' '}
              {partnerName || 'bạn đồng hành'}.
            </p>
          </div>

          {/* Mutual Best Friend Prompt on Session Wrap-up */}
          {activeRoom.guestUid && (
            <div className="max-w-lg mx-auto rounded-2xl border border-[#DCE8DF] bg-[#F7FBF8] p-5 space-y-3">
              <div className="flex items-center justify-center gap-2 text-sm font-bold text-[#112A1E]">
                <Heart className={`w-4 h-4 ${isBestFriendNow ? 'text-[#165B3D] fill-[#165B3D]' : 'text-[#165B3D]'}`} />
                {isBestFriendNow
                  ? `Bạn và ${partnerName} đã trở thành Bạn thân StudyWithMe`
                  : partnerWantsFriend
                    ? `${partnerName} muốn thêm bạn làm Bạn thân để hẹn học lại!`
                    : `Muốn gặp lại ${partnerName} ở những buổi ôn sau?`}
              </div>
              <p className="text-xs text-[#4B6859] leading-relaxed">
                {isBestFriendNow
                  ? 'Hai bạn đã lưu trong danh sách Bạn thân StudyWithMe và có thể nhấn Hẹn học lại bất kỳ lúc nào.'
                  : 'Khi cả hai cùng nhấn đồng ý, hai bạn sẽ được thêm vào danh sách Bạn thân StudyWithMe để hẹn học lại 1 chạm.'}
              </p>
              {!isBestFriendNow && (
                <button
                  type="button"
                  disabled={togglingFriend}
                  onClick={handleToggleBestFriend}
                  className={`inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition-colors whitespace-nowrap ${
                    iWantFriend
                      ? 'bg-[#E7F4EB] border border-[#BFE0C9] text-[#114B32]'
                      : 'bg-[#165B3D] text-white hover:bg-[#114830]'
                  }`}
                >
                  {iWantFriend ? <Check className="w-3.5 h-3.5" /> : <UserPlus className="w-3.5 h-3.5" />}
                  {iWantFriend
                    ? 'Đã gửi lời mời · Đang chờ bạn ấy đồng ý'
                    : partnerWantsFriend
                      ? 'Đồng ý kết Bạn thân ngay'
                      : 'Thêm làm Bạn thân để hẹn học lại'}
                </button>
              )}
            </div>
          )}

          <div className="flex flex-wrap items-center justify-center gap-3 pt-1">
            {!alreadyLogged && (
              <button
                type="button"
                disabled={savingTree}
                onClick={handleLogDateToFocusTree}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#E3F3E8] border border-[#BFE0C9] text-xs font-semibold text-[#165B3D] hover:bg-[#D5ECDC] whitespace-nowrap"
              >
                <Sprout className="w-4 h-4" />
                {savingTree ? 'Đang lưu...' : 'Ghi nhận vào Cây tập trung'}
              </button>
            )}
            <button
              type="button"
              onClick={() => handleLeaveRoom(true)}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#165B3D] text-white text-xs font-semibold hover:bg-[#114830] whitespace-nowrap"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              Tìm bạn học mới
            </button>
            <button
              type="button"
              onClick={() => handleLeaveRoom(false)}
              className="px-4 py-2.5 rounded-xl border border-[#D4E3D8] text-xs font-semibold text-[#314E3F] hover:bg-[#EDF5EF] whitespace-nowrap"
            >
              Về sảnh StudyWithMe Date
            </button>
          </div>
        </div>
      );
    }

    // Active / Matched Room UI
    const partnerMajor = isHost ? activeRoom.guestMajor : activeRoom.hostMajor;
    const partnerGoal = isHost ? activeRoom.guestGoal : activeRoom.hostGoal;
    const partnerCamOn = isHost ? activeRoom.guestCamOn : activeRoom.hostCamOn;
    const partnerMicOn = isHost ? activeRoom.guestMicOn : activeRoom.hostMicOn;
    const partnerReady = isHost ? activeRoom.guestReady : activeRoom.hostReady;
    const myReady = isHost ? activeRoom.hostReady : activeRoom.guestReady;

    const alreadyLogged = loggedFocusForRoomId === activeRoom.id;
    const quickPrompts = activeRoom.phase === 'break' ? BREAK_ICEBREAKERS : FOCUS_REACTIONS;
    const doneNotesCount = roomNotes.filter((n) => n.checked).length;

    return (
      <div className="space-y-5">
        {/* Room Header Strip */}
        <div className="rounded-2xl border border-[#DCE8DF] bg-white px-5 py-4 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="min-w-0 space-y-1">
            <div className="flex flex-wrap items-center gap-2 text-xs text-[#4B6859]">
              <span className="font-semibold text-[#165B3D]">
                {getVibeLabel(activeRoom.vibe)}
              </span>
              <span aria-hidden="true">·</span>
              <span className="font-medium text-[#112A1E]">
                Môn chung: {activeRoom.subject || 'Mọi môn học'}
              </span>
              <span aria-hidden="true">·</span>
              <span>
                {rtcState === 'connected'
                  ? 'Kết nối Video/Audio P2P trực tiếp'
                  : rtcState === 'connecting'
                    ? 'Đang đồng bộ kênh kết nối...'
                    : 'Đồng bộ thời gian thực'}
              </span>
            </div>
            <h2 className="text-base sm:text-lg font-bold text-[#112A1E] truncate">
              Bàn học đôi cùng {partnerName} · {partnerMajor}
            </h2>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <button
              type="button"
              disabled={togglingFriend || isBestFriendNow}
              onClick={handleToggleBestFriend}
              className={`inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl border text-xs font-semibold transition-colors whitespace-nowrap ${
                isBestFriendNow
                  ? 'bg-[#E7F4EB] border-[#BFE0C9] text-[#114B32]'
                  : partnerWantsFriend && !iWantFriend
                    ? 'bg-[#165B3D] border-[#165B3D] text-white hover:bg-[#114830]'
                    : iWantFriend
                      ? 'bg-[#F3F8F5] border-[#BFE0C9] text-[#165B3D] hover:bg-[#E7F4EB]'
                      : 'bg-white border-[#D4E3D8] text-[#112A1E] hover:bg-[#EDF5EF]'
              }`}
            >
              {isBestFriendNow ? (
                <>
                  <Heart className="w-3.5 h-3.5 fill-current" />
                  Đã là Bạn thân
                </>
              ) : partnerWantsFriend && !iWantFriend ? (
                <>
                  <UserPlus className="w-3.5 h-3.5" />
                  Đồng ý kết Bạn thân
                </>
              ) : iWantFriend ? (
                <>
                  <Check className="w-3.5 h-3.5" />
                  Đã mời Bạn thân
                </>
              ) : (
                <>
                  <UserPlus className="w-3.5 h-3.5" />
                  Thêm bạn thân
                </>
              )}
            </button>

            <button
              type="button"
              onClick={() => handleLeaveRoom(true)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl border border-[#D4E3D8] text-xs font-semibold text-[#314E3F] hover:bg-[#EDF5EF] whitespace-nowrap"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              Đổi bạn khác
            </button>
            <button
              type="button"
              onClick={() => handleLeaveRoom(false)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl border border-red-200 text-xs font-semibold text-red-700 hover:bg-red-50 whitespace-nowrap"
            >
              <LogOut className="w-3.5 h-3.5" />
              Rời phòng
            </button>
          </div>
        </div>

        {/* Main 2-Column Room Stage */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Left Stage: Dual Study Desk + Synced Pomodoro Clock */}
          <div className="lg:col-span-7 space-y-5">
            {/* Dual Video / Desk Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-stretch">
              {/* Local User Card */}
              <div className="rounded-2xl border border-[#DCE8DF] bg-[#112A1E] text-white overflow-hidden flex flex-col">
                <div className="relative aspect-[4/3] bg-[#0E2218] flex items-center justify-center">
                  {localCamOn ? (
                    <video
                      ref={localVideoRef}
                      autoPlay
                      muted
                      playsInline
                      className="w-full h-full object-cover scale-x-[-1]"
                    />
                  ) : (
                    <div className="text-center p-5 space-y-2">
                      <MascotAvatar size="lg" dark className="mx-auto" />
                      <p className="text-sm font-bold text-white">{displayName} (Bạn)</p>
                      <p className="text-xs text-[#A7D7B8]">{major}</p>
                    </div>
                  )}
                  <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent p-3.5 flex items-end justify-between gap-2">
                    <div className="min-w-0">
                      <p className="text-xs font-bold text-white truncate">
                        {displayName} (Bạn)
                      </p>
                      <p className="text-[11px] text-[#CBEAD4] truncate">{goal}</p>
                    </div>
                    <span className="text-[11px] font-semibold text-[#A7D7B8] shrink-0">
                      {localMicOn ? 'Mic mở' : 'Tắt mic'}
                    </span>
                  </div>
                </div>
                <div className="px-4 py-2.5 bg-[#153425] flex items-center justify-between text-xs text-[#CBEAD4]">
                  <span>{myReady ? 'Đã sẵn sàng học' : 'Đang chuẩn bị'}</span>
                  <span>{localCamOn ? 'Cam đang bật' : 'Học không cam'}</span>
                </div>
              </div>

              {/* Remote Partner Card */}
              <div className="rounded-2xl border border-[#DCE8DF] bg-[#112A1E] text-white overflow-hidden flex flex-col">
                <div className="relative aspect-[4/3] bg-[#0E2218] flex items-center justify-center">
                  {/* Always keep remoteVideo mounted so WebRTC remote audio plays even when partner's cam is off */}
                  <video
                    ref={remoteVideoRef}
                    autoPlay
                    playsInline
                    className={
                      partnerCamOn && remoteHasVideo
                        ? 'w-full h-full object-cover'
                        : 'sr-only'
                    }
                  />
                  {!(partnerCamOn && remoteHasVideo) && (
                    <div className="text-center p-5 space-y-2">
                      <div className="w-16 h-16 rounded-2xl bg-[#1A4230] border border-[#2C6148] flex items-center justify-center mx-auto text-xl font-bold text-[#A7D7B8]">
                        {partnerName.slice(0, 1).toUpperCase()}
                      </div>
                      <p className="text-sm font-bold text-white">{partnerName}</p>
                      <p className="text-xs text-[#A7D7B8]">{partnerMajor}</p>
                    </div>
                  )}
                  <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent p-3.5 flex items-end justify-between gap-2">
                    <div className="min-w-0">
                      <p className="text-xs font-bold text-white truncate">{partnerName}</p>
                      <p className="text-[11px] text-[#CBEAD4] truncate">{partnerGoal}</p>
                    </div>
                    <span className="text-[11px] font-semibold text-[#A7D7B8] shrink-0">
                      {partnerMicOn ? 'Mic mở' : 'Tắt mic'}
                    </span>
                  </div>
                </div>
                <div className="px-4 py-2.5 bg-[#153425] flex items-center justify-between text-xs text-[#CBEAD4]">
                  <span>{partnerReady ? 'Bạn học đã sẵn sàng' : 'Đang ổn định bàn học'}</span>
                  <span>{partnerCamOn ? 'Đang bật cam' : 'Đang tắt cam'}</span>
                </div>
              </div>
            </div>

            {mediaError && (
              <p className="text-xs text-amber-800 bg-amber-50 border border-amber-200 rounded-xl px-4 py-2.5">
                {mediaError}
              </p>
            )}

            {/* Media & Readiness Controls */}
            <div className="rounded-2xl border border-[#DCE8DF] bg-white p-4 flex flex-wrap items-center justify-between gap-3">
              <div className="flex flex-wrap items-center gap-2.5">
                <button
                  type="button"
                  onClick={handleToggleRoomCam}
                  className={`inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl border text-xs font-semibold transition-colors whitespace-nowrap ${
                    localCamOn
                      ? 'bg-[#165B3D] border-[#165B3D] text-white'
                      : 'bg-white border-[#D4E3D8] text-[#314E3F] hover:bg-[#EDF5EF]'
                  }`}
                >
                  {localCamOn ? <Camera className="w-3.5 h-3.5" /> : <CameraOff className="w-3.5 h-3.5" />}
                  {localCamOn ? 'Tắt Camera' : 'Bật Camera'}
                </button>
                <button
                  type="button"
                  onClick={handleToggleRoomMic}
                  className={`inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl border text-xs font-semibold transition-colors whitespace-nowrap ${
                    localMicOn
                      ? 'bg-[#165B3D] border-[#165B3D] text-white'
                      : 'bg-white border-[#D4E3D8] text-[#314E3F] hover:bg-[#EDF5EF]'
                  }`}
                >
                  {localMicOn ? <Mic className="w-3.5 h-3.5" /> : <MicOff className="w-3.5 h-3.5" />}
                  {localMicOn ? 'Tắt Micro' : 'Bật Micro'}
                </button>
              </div>

              <button
                type="button"
                onClick={handleToggleReady}
                className={`inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold transition-colors whitespace-nowrap ${
                  myReady
                    ? 'bg-[#E7F4EB] border border-[#BFE0C9] text-[#114B32]'
                    : 'bg-[#165B3D] text-white hover:bg-[#114830]'
                }`}
              >
                <Check className="w-3.5 h-3.5" />
                {myReady ? 'Đã sẵn sàng' : 'Bấm Sẵn sàng'}
              </button>
            </div>

            {/* Shared Synchronized Pomodoro Clock */}
            <div className="rounded-2xl border border-[#DCE8DF] bg-white p-6 space-y-5">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <p className="text-xs font-semibold text-[#165B3D]">
                    {activeRoom.phase === 'focus'
                      ? `Đồng hồ đôi · Phiên tập trung (${activeRoom.durationMinutes} phút)`
                      : 'Giờ giải lao 5 phút · Làm quen cùng bạn học'}
                  </p>
                  <p className="text-4xl sm:text-5xl font-mono font-bold text-[#112A1E] tabular-nums tracking-tight mt-1">
                    {formatClock(displaySecondsLeft)}
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-2.5">
                  <button
                    type="button"
                    onClick={handleToggleTimer}
                    className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#165B3D] text-white text-xs font-semibold hover:bg-[#114830] whitespace-nowrap"
                  >
                    {activeRoom.timerRunning ? (
                      <>
                        <Pause className="w-3.5 h-3.5" />
                        Tạm dừng
                      </>
                    ) : (
                      <>
                        <Play className="w-3.5 h-3.5" />
                        Bắt đầu đồng bộ
                      </>
                    )}
                  </button>

                  {activeRoom.phase === 'focus' ? (
                    <button
                      type="button"
                      onClick={() => handleSwitchPhase('break')}
                      className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl border border-[#D4E3D8] text-xs font-semibold text-[#314E3F] hover:bg-[#EDF5EF] whitespace-nowrap"
                    >
                      <Coffee className="w-3.5 h-3.5" />
                      Giải lao 5p
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => handleSwitchPhase('focus')}
                      className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl border border-[#D4E3D8] text-xs font-semibold text-[#314E3F] hover:bg-[#EDF5EF] whitespace-nowrap"
                    >
                      <BookOpen className="w-3.5 h-3.5" />
                      Vào phiên học mới
                    </button>
                  )}
                </div>
              </div>

              <div className="pt-4 border-t border-[#E5EFE8] flex flex-wrap items-center justify-between gap-3">
                <p className="text-xs text-[#4B6859]">
                  Đồng hồ được đồng bộ thời gian thực giữa cả hai sinh viên trong phòng.
                </p>
                <button
                  type="button"
                  disabled={savingTree || alreadyLogged}
                  onClick={handleLogDateToFocusTree}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#E7F4EB] border border-[#BFE0C9] text-xs font-semibold text-[#114B32] hover:bg-[#D7EDDE] disabled:opacity-60 whitespace-nowrap"
                >
                  <Sprout className="w-3.5 h-3.5" />
                  {alreadyLogged
                    ? 'Đã ghi nhận vào Cây tập trung'
                    : savingTree
                      ? 'Đang lưu...'
                      : 'Lưu phút học vào Cây tập trung'}
                </button>
              </div>
            </div>
          </div>

          {/* Right Panel: Tabbed Shared Revision ("Cùng ôn 1 môn") + Live Chat */}
          <div className="lg:col-span-5 rounded-2xl border border-[#DCE8DF] bg-white flex flex-col h-[620px]">
            {/* Tab Switcher */}
            <div className="p-2 border-b border-[#E5EFE8] bg-[#F7FBF8] rounded-t-2xl grid grid-cols-2 gap-1.5">
              <button
                type="button"
                onClick={() => setRightTab('study')}
                className={`inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold transition-colors whitespace-nowrap ${
                  rightTab === 'study'
                    ? 'bg-[#165B3D] text-white'
                    : 'text-[#314E3F] hover:bg-[#E7F2EA]'
                }`}
              >
                <ListChecks className="w-3.5 h-3.5" />
                Cùng ôn 1 môn
                {roomNotes.length > 0 && (
                  <span className="font-mono tabular-nums opacity-85">
                    ({doneNotesCount}/{roomNotes.length})
                  </span>
                )}
              </button>
              <button
                type="button"
                onClick={() => setRightTab('chat')}
                className={`inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold transition-colors whitespace-nowrap ${
                  rightTab === 'chat'
                    ? 'bg-[#165B3D] text-white'
                    : 'text-[#314E3F] hover:bg-[#E7F2EA]'
                }`}
              >
                <MessageSquareText className="w-3.5 h-3.5" />
                Trò chuyện
                {roomMessages.length > 0 && (
                  <span className="font-mono tabular-nums opacity-85">
                    ({roomMessages.length})
                  </span>
                )}
              </button>
            </div>

            {rightTab === 'study' ? (
              <>
                {/* Shared Subject & Topic Sync Banner */}
                <div className="p-4 border-b border-[#E5EFE8] bg-[#F9FCFA] space-y-2.5">
                  {editingTopic ? (
                    <form onSubmit={handleSaveSharedTopic} className="space-y-2">
                      <div>
                        <label className="block text-[11px] font-semibold text-[#314E3F] mb-1">
                          Môn học chung
                        </label>
                        <input
                          type="text"
                          maxLength={60}
                          required
                          value={topicSubjectInput}
                          onChange={(e) => setTopicSubjectInput(e.target.value)}
                          placeholder="Ví dụ: Giải tích 1, IELTS Reading..."
                          className="w-full rounded-lg border border-[#D4E3D8] bg-white px-3 py-1.5 text-xs text-[#112A1E] focus:outline-none focus:ring-2 focus:ring-[#165B3D]/25"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] font-semibold text-[#314E3F] mb-1">
                          Chương / Chủ đề / Đề cương đang ôn
                        </label>
                        <input
                          type="text"
                          maxLength={140}
                          value={topicDetailInput}
                          onChange={(e) => setTopicDetailInput(e.target.value)}
                          placeholder="Ví dụ: Chương 3 tích phân suy rộng & đề 2024"
                          className="w-full rounded-lg border border-[#D4E3D8] bg-white px-3 py-1.5 text-xs text-[#112A1E] focus:outline-none focus:ring-2 focus:ring-[#165B3D]/25"
                        />
                      </div>
                      <div className="flex items-center justify-end gap-2 pt-1">
                        <button
                          type="button"
                          onClick={() => setEditingTopic(false)}
                          className="px-3 py-1.5 rounded-lg border border-[#D4E3D8] text-[11px] font-semibold text-[#314E3F] hover:bg-[#EDF5EF]"
                        >
                          Hủy
                        </button>
                        <button
                          type="submit"
                          disabled={savingTopic}
                          className="px-3 py-1.5 rounded-lg bg-[#165B3D] text-white text-[11px] font-semibold hover:bg-[#114830] disabled:opacity-50"
                        >
                          {savingTopic ? 'Đang lưu...' : 'Lưu đồng bộ'}
                        </button>
                      </div>
                    </form>
                  ) : (
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0 space-y-0.5">
                        <p className="text-[11px] font-semibold text-[#165B3D]">
                          Môn đang cùng ôn
                        </p>
                        <p className="text-sm font-bold text-[#112A1E] truncate">
                          {activeRoom.subject || 'Mọi môn học'}
                        </p>
                        <p className="text-xs text-[#4B6859] leading-relaxed">
                          {activeRoom.sharedTopic
                            ? activeRoom.sharedTopic
                            : 'Chưa ghi chủ đề cụ thể — hai bạn có thể thống nhất chương/đề cần ôn tại đây.'}
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={handleStartEditTopic}
                        className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-[#D4E3D8] bg-white text-[11px] font-semibold text-[#314E3F] hover:bg-[#EDF5EF] whitespace-nowrap shrink-0"
                      >
                        <Edit3 className="w-3 h-3" />
                        Chốt môn/chủ đề
                      </button>
                    </div>
                  )}
                </div>

                {/* Shared Checklist / Revision Notes */}
                <div className="flex-1 overflow-y-auto p-4 space-y-2.5 bg-white">
                  {roomNotes.length === 0 ? (
                    <div className="h-full flex flex-col items-center justify-center text-center px-3 space-y-3">
                      <BookOpen className="w-7 h-7 text-[#8FB59F]" />
                      <div className="space-y-1">
                        <p className="text-xs font-bold text-[#112A1E]">
                          Bảng mục tiêu & câu hỏi ôn tập chung
                        </p>
                        <p className="text-[11px] text-[#4B6859] leading-relaxed">
                          Cả bạn và {partnerName} đều có thể thêm câu hỏi, phần bài tập hoặc đánh dấu hoàn thành cùng nhau.
                        </p>
                      </div>
                      <div className="w-full space-y-1.5 pt-1">
                        {STUDY_NOTE_TEMPLATES.map((tpl) => (
                          <button
                            key={tpl}
                            type="button"
                            onClick={() => handleAddNote(tpl)}
                            className="w-full text-left text-[11px] px-3 py-2 rounded-xl border border-[#DCE8DF] bg-[#F7FBF8] text-[#284738] hover:border-[#165B3D] hover:bg-[#EDF5EF] transition-colors"
                          >
                            + {tpl}
                          </button>
                        ))}
                      </div>
                    </div>
                  ) : (
                    roomNotes.map((note) => {
                      const isMine = note.createdBy === user.uid;
                      return (
                        <div
                          key={note.id}
                          className={`rounded-xl border p-3 flex items-start gap-2.5 transition-colors ${
                            note.checked
                              ? 'border-[#D4E6DA] bg-[#F4FAF6]'
                              : 'border-[#DCE8DF] bg-white'
                          }`}
                        >
                          <button
                            type="button"
                            onClick={() =>
                              toggleStudyDateNote({
                                roomId: activeRoom.id,
                                noteId: note.id,
                                checked: !note.checked,
                              })
                            }
                            aria-label="Đánh dấu đã ôn xong"
                            className={`mt-0.5 w-4 h-4 rounded border flex items-center justify-center shrink-0 transition-colors ${
                              note.checked
                                ? 'bg-[#165B3D] border-[#165B3D] text-white'
                                : 'border-[#8FB59F] bg-white hover:border-[#165B3D]'
                            }`}
                          >
                            {note.checked && <Check className="w-3 h-3" />}
                          </button>
                          <div className="flex-1 min-w-0">
                            <p
                              className={`text-xs leading-relaxed break-words ${
                                note.checked
                                  ? 'line-through text-[#5E7D6D]'
                                  : 'text-[#112A1E] font-medium'
                              }`}
                            >
                              {note.content}
                            </p>
                            <p className="text-[10px] text-[#6D8B7A] mt-1">
                              {isMine ? 'Bạn' : note.authorName} ·{' '}
                              {formatTimeAgoVi(note.createdAt?.toMillis?.() || nowMs)}
                            </p>
                          </div>
                          {isMine && (
                            <button
                              type="button"
                              onClick={() =>
                                deleteStudyDateNote({ roomId: activeRoom.id, noteId: note.id })
                              }
                              aria-label="Xóa mục ôn tập"
                              className="p-1 rounded-md text-[#6D8B7A] hover:text-red-600 hover:bg-red-50 shrink-0"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      );
                    })
                  )}
                </div>

                {/* Add Note Form */}
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    handleAddNote();
                  }}
                  className="p-3.5 border-t border-[#E5EFE8] bg-white flex items-center gap-2 rounded-b-2xl"
                >
                  <input
                    type="text"
                    maxLength={300}
                    value={noteInput}
                    onChange={(e) => setNoteInput(e.target.value)}
                    placeholder="Thêm mục ôn tập hoặc câu hỏi chung..."
                    className="flex-1 rounded-xl border border-[#D4E3D8] px-3 py-2 text-xs text-[#112A1E] focus:outline-none focus:ring-2 focus:ring-[#165B3D]/25"
                  />
                  <button
                    type="submit"
                    disabled={addingNote || !noteInput.trim()}
                    className="inline-flex items-center justify-center gap-1 px-3.5 py-2 rounded-xl bg-[#165B3D] text-white text-xs font-semibold hover:bg-[#114830] disabled:opacity-50 shrink-0 whitespace-nowrap"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    Thêm
                  </button>
                </form>
              </>
            ) : (
              <>
                <div className="px-5 py-3.5 border-b border-[#E5EFE8] space-y-0.5">
                  <h3 className="text-sm font-bold text-[#112A1E]">
                    {activeRoom.phase === 'break'
                      ? 'Góc trò chuyện giờ giải lao'
                      : 'Nhắn nhẹ & giữ nhịp học'}
                  </h3>
                  <p className="text-xs text-[#4B6859]">
                    {activeRoom.phase === 'break'
                      ? 'Chọn nhanh câu hỏi gợi ý bên dưới để làm quen.'
                      : 'Ưu tiên im lặng tập trung, gửi lời khích lệ nhanh khi cần.'}
                  </p>
                </div>

                <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-[#F9FCFA]">
                  {roomMessages.length === 0 ? (
                    <div className="h-full flex flex-col items-center justify-center text-center px-3 space-y-2">
                      <HeartHandshake className="w-7 h-7 text-[#8FB59F]" />
                      <p className="text-xs font-semibold text-[#112A1E]">
                        Chúc hai bạn có phiên StudyWithMe Date hiệu quả!
                      </p>
                      <p className="text-[11px] text-[#4B6859] leading-relaxed">
                        Gửi lời chào hoặc chọn một gợi ý nhanh để bắt đầu phiên học cùng {partnerName}.
                      </p>
                    </div>
                  ) : (
                    roomMessages.map((m) => {
                      const mine = m.senderUid === user.uid;
                      return (
                        <div
                          key={m.id}
                          className={`flex flex-col ${mine ? 'items-end' : 'items-start'}`}
                        >
                          <div
                            className={`max-w-[88%] rounded-2xl px-3.5 py-2 text-xs leading-relaxed ${
                              mine
                                ? 'bg-[#165B3D] text-white'
                                : 'bg-white border border-[#DCE8DF] text-[#112A1E]'
                            }`}
                          >
                            {!mine && (
                              <p className="text-[10px] font-semibold text-[#4B6859] mb-0.5">
                                {m.senderName}
                              </p>
                            )}
                            <p className="whitespace-pre-wrap break-words">{m.content}</p>
                          </div>
                          <span className="text-[10px] text-[#6D8B7A] mt-0.5 px-1">
                            {formatTimeAgoVi(m.createdAt?.toMillis?.() || nowMs)}
                          </span>
                        </div>
                      );
                    })
                  )}
                  <div ref={chatEndRef} />
                </div>

                {/* Quick Prompts / Icebreakers */}
                <div className="px-4 py-2.5 border-t border-[#E5EFE8] bg-[#F5FAF6] space-y-1.5">
                  <p className="text-[11px] font-semibold text-[#165B3D]">
                    {activeRoom.phase === 'break' ? 'Gợi ý bắt chuyện giờ nghỉ' : 'Khích lệ nhanh'}
                  </p>
                  <div className="flex flex-col gap-1.5 max-h-24 overflow-y-auto">
                    {quickPrompts.map((prompt) => (
                      <button
                        key={prompt}
                        type="button"
                        onClick={() =>
                          handleSendChat(
                            prompt,
                            activeRoom.phase === 'break' ? 'checkin' : 'reaction',
                          )
                        }
                        className="text-left text-[11px] px-2.5 py-1.5 rounded-lg bg-white border border-[#D4E3D8] text-[#284738] hover:border-[#165B3D] hover:bg-[#EDF5EF] transition-colors"
                      >
                        {prompt}
                      </button>
                    ))}
                  </div>
                </div>

                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    handleSendChat();
                  }}
                  className="p-3.5 border-t border-[#E5EFE8] bg-white flex items-center gap-2 rounded-b-2xl"
                >
                  <input
                    type="text"
                    maxLength={600}
                    value={chatInput}
                    onChange={(e) => setChatInput(e.target.value)}
                    placeholder={
                      activeRoom.phase === 'break'
                        ? 'Nhắn làm quen giờ giải lao...'
                        : 'Gửi tin nhắn cho bạn học...'
                    }
                    className="flex-1 rounded-xl border border-[#D4E3D8] px-3 py-2 text-xs text-[#112A1E] focus:outline-none focus:ring-2 focus:ring-[#165B3D]/25"
                  />
                  <button
                    type="submit"
                    disabled={sendingChat || !chatInput.trim()}
                    className="inline-flex items-center justify-center gap-1 px-3.5 py-2 rounded-xl bg-[#165B3D] text-white text-xs font-semibold hover:bg-[#114830] disabled:opacity-50 shrink-0 whitespace-nowrap"
                  >
                    <Send className="w-3.5 h-3.5" />
                    Gửi
                  </button>
                </form>
              </>
            )}
          </div>
        </div>
      </div>
    );
  }

  // --- VIEW 2: LOBBY & MATCHMAKING SETUP ---
  const isSpecificLobbySubject = normalizeSubject(effectiveSubject) !== 'mọi môn học';

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
      {/* Left: Profile & Match Setup */}
      <div className="lg:col-span-7 rounded-2xl border border-[#DCE8DF] bg-white p-6 space-y-5">
        <div className="flex items-start justify-between gap-4 pb-4 border-b border-[#E5EFE8]">
          <div>
            <h2 className="text-xl font-bold text-[#112A1E]">
              StudyWithMe Date từ xa cho sinh viên
            </h2>
            <p className="text-xs text-[#4B6859] mt-1 leading-relaxed">
              Ghép đôi 1-1 cùng sinh viên khác để bật Pomodoro, cùng ôn 1 môn chung với bảng ghi chú đồng bộ và kết Bạn thân để hẹn học lại.
            </p>
          </div>
          <Video className="w-5 h-5 text-[#165B3D] shrink-0 mt-1" />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label
              htmlFor="sd-name"
              className="block text-xs font-semibold text-[#112A1E] mb-1.5"
            >
              Tên / Biệt danh hiển thị
            </label>
            <input
              id="sd-name"
              type="text"
              maxLength={80}
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              placeholder="Minh Anh"
              className="w-full rounded-xl border border-[#D4E3D8] px-3.5 py-2.5 text-sm text-[#112A1E] focus:outline-none focus:ring-2 focus:ring-[#165B3D]/25"
            />
          </div>

          <div>
            <label
              htmlFor="sd-major"
              className="block text-xs font-semibold text-[#112A1E] mb-1.5"
            >
              Trường / Ngành học
            </label>
            <input
              id="sd-major"
              type="text"
              maxLength={80}
              value={major}
              onChange={(e) => setMajor(e.target.value)}
              placeholder="ĐH Kinh tế · Marketing năm 2"
              className="w-full rounded-xl border border-[#D4E3D8] px-3.5 py-2.5 text-sm text-[#112A1E] focus:outline-none focus:ring-2 focus:ring-[#165B3D]/25"
            />
          </div>
        </div>

        {/* Shared Common Subject Picker */}
        <div className="rounded-xl border border-[#DCE8DF] bg-[#F7FBF8] p-4 space-y-3">
          <div className="flex items-center justify-between gap-2">
            <p className="text-xs font-bold text-[#112A1E]">
              Cùng ôn 1 môn chung (Tùy chọn ghép theo môn)
            </p>
            <span className="text-[11px] font-semibold text-[#165B3D]">
              {effectiveSubject}
            </span>
          </div>

          <div className="flex flex-wrap gap-1.5">
            {SUBJECT_PRESETS.map((sub) => {
              const active = selectedSubjectPreset === sub;
              return (
                <button
                  key={sub}
                  type="button"
                  onClick={() => setSelectedSubjectPreset(sub)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                    active
                      ? 'bg-[#165B3D] text-white'
                      : 'bg-white border border-[#D4E3D8] text-[#314E3F] hover:bg-[#EDF5EF]'
                  }`}
                >
                  {sub}
                </button>
              );
            })}
            <button
              type="button"
              onClick={() => setSelectedSubjectPreset('__custom__')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                selectedSubjectPreset === '__custom__'
                  ? 'bg-[#165B3D] text-white'
                  : 'bg-white border border-[#D4E3D8] text-[#314E3F] hover:bg-[#EDF5EF]'
              }`}
            >
              Môn khác...
            </button>
          </div>

          {selectedSubjectPreset === '__custom__' && (
            <input
              type="text"
              maxLength={60}
              value={customSubject}
              onChange={(e) => setCustomSubject(e.target.value)}
              placeholder="Nhập tên môn học chung (VD: Xác suất thống kê, Cấu trúc dữ liệu...)"
              className="w-full rounded-xl border border-[#D4E3D8] bg-white px-3.5 py-2 text-xs text-[#112A1E] focus:outline-none focus:ring-2 focus:ring-[#165B3D]/25"
            />
          )}

          {isSpecificLobbySubject && (
            <label className="flex items-center gap-2 text-xs text-[#314E3F] cursor-pointer pt-0.5">
              <input
                type="checkbox"
                checked={strictSubjectMatch}
                onChange={(e) => setStrictSubjectMatch(e.target.checked)}
                className="rounded border-[#8FB59F] text-[#165B3D] focus:ring-[#165B3D]"
              />
              <span>Chỉ ghép đôi với sinh viên đang chọn đúng môn {effectiveSubject}</span>
            </label>
          )}
        </div>

        <div>
          <label
            htmlFor="sd-goal"
            className="block text-xs font-semibold text-[#112A1E] mb-1.5"
          >
            Mục tiêu phiên học hôm nay
          </label>
          <input
            id="sd-goal"
            type="text"
            maxLength={160}
            value={goal}
            onChange={(e) => setGoal(e.target.value)}
            placeholder="Ví dụ: Viết xong phần mở đầu tiểu luận / Ôn 2 đề IELTS Reading"
            className="w-full rounded-xl border border-[#D4E3D8] px-3.5 py-2.5 text-sm text-[#112A1E] focus:outline-none focus:ring-2 focus:ring-[#165B3D]/25"
          />
        </div>

        {/* Vibe Selector */}
        <div className="space-y-2">
          <p className="text-xs font-semibold text-[#112A1E]">Phong cách StudyWithMe Date</p>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
            {VIBE_OPTIONS.map((opt) => {
              const active = vibe === opt.id;
              return (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => setVibe(opt.id)}
                  className={`text-left p-3.5 rounded-xl border transition-colors ${
                    active
                      ? 'border-[#165B3D] bg-[#EAF5EE] text-[#112A1E]'
                      : 'border-[#DCE8DF] bg-white text-[#314E3F] hover:bg-[#F5FAF6]'
                  }`}
                >
                  <p className="text-xs font-bold text-[#112A1E]">{opt.title}</p>
                  <p className="text-[11px] text-[#4B6859] mt-1 leading-relaxed">{opt.desc}</p>
                </button>
              );
            })}
          </div>
        </div>

        {/* Duration + Camera/Mic pre-check */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pt-1">
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-[#112A1E] mr-1">Thời lượng:</span>
            {[25, 50, 90].map((mins) => (
              <button
                key={mins}
                type="button"
                onClick={() => setDurationMinutes(mins)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold tabular-nums transition-colors ${
                  durationMinutes === mins
                    ? 'bg-[#165B3D] text-white'
                    : 'bg-[#EEF5F0] text-[#314E3F] hover:bg-[#DFECE3]'
                }`}
              >
                {mins}p
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleToggleLobbyCam}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-semibold transition-colors whitespace-nowrap ${
                localCamOn
                  ? 'bg-[#165B3D] border-[#165B3D] text-white'
                  : 'bg-white border-[#D4E3D8] text-[#314E3F] hover:bg-[#EDF5EF]'
              }`}
            >
              {localCamOn ? <Camera className="w-3.5 h-3.5" /> : <CameraOff className="w-3.5 h-3.5" />}
              {localCamOn ? 'Cam sẵn sàng' : 'Thử Camera'}
            </button>
            <button
              type="button"
              onClick={handleToggleLobbyMic}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-semibold transition-colors whitespace-nowrap ${
                localMicOn
                  ? 'bg-[#165B3D] border-[#165B3D] text-white'
                  : 'bg-white border-[#D4E3D8] text-[#314E3F] hover:bg-[#EDF5EF]'
              }`}
            >
              {localMicOn ? <Mic className="w-3.5 h-3.5" /> : <MicOff className="w-3.5 h-3.5" />}
              {localMicOn ? 'Mic mở' : 'Tắt Mic'}
            </button>
          </div>
        </div>

        {localCamOn && (
          <div className="rounded-xl overflow-hidden bg-[#0E2218] aspect-video max-h-52 relative">
            <video
              ref={localVideoRef}
              autoPlay
              muted
              playsInline
              className="w-full h-full object-cover scale-x-[-1]"
            />
            <span className="absolute bottom-2.5 left-3 text-[11px] font-medium text-white bg-black/60 px-2.5 py-1 rounded-md">
              Xem trước góc bàn học của bạn
            </span>
          </div>
        )}

        {mediaError && (
          <p className="text-xs text-amber-800 bg-amber-50 border border-amber-200 rounded-xl px-4 py-2.5">
            {mediaError}
          </p>
        )}

        {actionError && (
          <p className="text-xs text-red-700 bg-red-50 border border-red-200 rounded-xl px-4 py-2.5">
            {actionError}
          </p>
        )}

        <button
          type="button"
          disabled={joining}
          onClick={handleFindRandomMatch}
          className="w-full py-3.5 px-5 rounded-xl bg-[#165B3D] text-white text-sm font-bold hover:bg-[#114830] disabled:opacity-50 transition-colors flex items-center justify-center gap-2"
        >
          <Users className="w-4 h-4" />
          {joining
            ? 'Đang tìm bạn học phù hợp...'
            : isSpecificLobbySubject
              ? `Ghép đôi cùng ôn ${effectiveSubject}`
              : 'Ghép đôi StudyWithMe Date ngẫu nhiên'}
        </button>
      </div>

      {/* Right Column: Friend Invites + Live Waiting Rooms + Best Friends List */}
      <div className="lg:col-span-5 space-y-6">
        {/* Live Private Invitations from Best Friends */}
        {friendInvites.length > 0 && (
          <div className="rounded-2xl border-2 border-[#165B3D] bg-[#EAF5EE] p-5 space-y-3">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <CalendarClock className="w-4 h-4 text-[#165B3D]" />
                <h3 className="text-sm font-bold text-[#112A1E]">
                  Lời mời Hẹn học lại ({friendInvites.length})
                </h3>
              </div>
              <span className="text-[11px] font-semibold text-[#165B3D]">Từ Bạn thân</span>
            </div>

            <div className="space-y-2.5">
              {friendInvites.map((inv) => (
                <div
                  key={inv.id}
                  className="rounded-xl border border-[#BFE0C9] bg-white p-3.5 space-y-2"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <p className="text-sm font-bold text-[#112A1E] truncate">
                        {inv.hostName}
                      </p>
                      <p className="text-xs text-[#165B3D] font-medium truncate">
                        Môn ôn: {inv.subject || 'Mọi môn học'}
                      </p>
                    </div>
                    <span className="text-xs font-mono font-semibold text-[#112A1E] tabular-nums shrink-0">
                      {inv.durationMinutes}p
                    </span>
                  </div>
                  <p className="text-xs text-[#4B6859]">{inv.hostGoal}</p>
                  <button
                    type="button"
                    disabled={joining}
                    onClick={() => handleJoinSpecificRoom(inv.id)}
                    className="w-full py-2 px-3 rounded-lg bg-[#165B3D] text-white text-xs font-semibold hover:bg-[#114830] disabled:opacity-50"
                  >
                    Vào học lại ngay
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Open Public Waiting Rooms */}
        <div className="rounded-2xl border border-[#DCE8DF] bg-white p-6 space-y-4">
          <div className="flex items-center justify-between gap-2 pb-3 border-b border-[#E5EFE8]">
            <div>
              <h3 className="text-base font-bold text-[#112A1E]">
                Sinh viên đang chờ ghép đôi
              </h3>
              <p className="text-xs text-[#4B6859] mt-0.5 tabular-nums">
                {visibleWaitingRooms.length} phòng đang mở theo thời gian thực
              </p>
            </div>
            <Clock className="w-4 h-4 text-[#165B3D]" />
          </div>

          {isSpecificLobbySubject && (
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => setLobbySubjectFilter('all')}
                className={`px-3 py-1 rounded-lg text-[11px] font-semibold transition-colors ${
                  lobbySubjectFilter === 'all'
                    ? 'bg-[#165B3D] text-white'
                    : 'bg-[#EEF5F0] text-[#314E3F] hover:bg-[#DFECE3]'
                }`}
              >
                Tất cả phòng
              </button>
              <button
                type="button"
                onClick={() => setLobbySubjectFilter('matching')}
                className={`px-3 py-1 rounded-lg text-[11px] font-semibold transition-colors truncate ${
                  lobbySubjectFilter === 'matching'
                    ? 'bg-[#165B3D] text-white'
                    : 'bg-[#EEF5F0] text-[#314E3F] hover:bg-[#DFECE3]'
                }`}
              >
                Đúng môn: {effectiveSubject}
              </button>
            </div>
          )}

          {visibleWaitingRooms.length === 0 ? (
            <div className="rounded-xl border border-dashed border-[#CBE0D1] bg-[#F7FBF8] p-5 text-center space-y-2">
              <MessageSquareText className="w-6 h-6 text-[#8FB59F] mx-auto" />
              <p className="text-sm font-semibold text-[#112A1E]">
                {lobbySubjectFilter === 'matching'
                  ? `Chưa có ai đang chờ môn ${effectiveSubject}`
                  : 'Hiện chưa có bạn nào khác trong hàng chờ'}
              </p>
              <p className="text-xs text-[#4B6859] leading-relaxed">
                Hãy nhấn nút ghép đôi bên trái để mở bàn học trước — sinh viên tiếp theo tham gia sẽ được ghép thẳng với bạn.
              </p>
            </div>
          ) : (
            <div className="space-y-3 max-h-[340px] overflow-y-auto pr-0.5">
              {visibleWaitingRooms.map((room) => (
                <div
                  key={room.id}
                  className="rounded-xl border border-[#DCE8DF] bg-[#F9FCFA] p-4 space-y-2"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <p className="text-sm font-bold text-[#112A1E] truncate">
                        {room.hostName}
                      </p>
                      <p className="text-xs text-[#165B3D] font-medium truncate">
                        {room.hostMajor}
                      </p>
                    </div>
                    <span className="text-xs font-mono font-semibold text-[#112A1E] tabular-nums shrink-0">
                      {room.durationMinutes}p
                    </span>
                  </div>

                  <p className="text-xs font-semibold text-[#112A1E]">
                    Môn ôn: {room.subject || 'Mọi môn học'}
                  </p>
                  <p className="text-xs text-[#314E3F] leading-relaxed">
                    Mục tiêu: {room.hostGoal}
                  </p>

                  <div className="flex items-center justify-between gap-2 pt-2 border-t border-[#E5EFE8]">
                    <span className="text-[11px] text-[#4B6859]">
                      {getVibeLabel(room.vibe)} · {room.hostCamOn ? 'Có cam' : 'Không cam'}
                    </span>
                    <button
                      type="button"
                      disabled={joining}
                      onClick={() => handleJoinSpecificRoom(room.id)}
                      className="px-3.5 py-1.5 rounded-lg bg-[#165B3D] text-white text-xs font-semibold hover:bg-[#114830] disabled:opacity-50 whitespace-nowrap"
                    >
                      Vào Date học cùng
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Best Friends List for Re-meeting */}
        <div className="rounded-2xl border border-[#DCE8DF] bg-white p-6 space-y-4">
          <div className="flex items-center justify-between gap-2 pb-3 border-b border-[#E5EFE8]">
            <div>
              <h3 className="text-base font-bold text-[#112A1E]">
                Bạn thân StudyWithMe
              </h3>
              <p className="text-xs text-[#4B6859] mt-0.5 tabular-nums">
                {studyFriends.length} bạn hợp cạ để hẹn học lại
              </p>
            </div>
            <Heart className="w-4 h-4 text-[#165B3D]" />
          </div>

          {studyFriends.length === 0 ? (
            <p className="text-xs text-[#4B6859] leading-relaxed bg-[#F7FBF8] border border-[#E5EFE8] rounded-xl p-4">
              Trong phòng học đôi hoặc lúc kết thúc phiên, bạn có thể nhấn <strong>Thêm bạn thân</strong>. Khi cả hai đồng ý, bạn thân sẽ xuất hiện tại đây để hẹn học lại 1 chạm.
            </p>
          ) : (
            <div className="space-y-2.5 max-h-[280px] overflow-y-auto pr-0.5">
              {studyFriends.map((friend) => {
                const isFirst = friend.uidA === user.uid;
                const friendUid = isFirst ? friend.uidB : friend.uidA;
                const friendName = isFirst ? friend.nameB : friend.nameA;
                const friendMajor = isFirst ? friend.majorB : friend.majorA;
                const confirming = confirmRemoveFriendId === friend.id;

                return (
                  <div
                    key={friend.id}
                    className="rounded-xl border border-[#DCE8DF] bg-[#F9FCFA] p-3.5 space-y-2.5"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <p className="text-sm font-bold text-[#112A1E] truncate">
                          {friendName}
                        </p>
                        <p className="text-xs text-[#4B6859] truncate">{friendMajor}</p>
                        <p className="text-[11px] font-medium text-[#165B3D] mt-0.5">
                          Môn ôn gần nhất: {friend.commonSubject}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center justify-between gap-2 pt-2 border-t border-[#E5EFE8]">
                      {confirming ? (
                        <div className="flex items-center gap-2">
                          <span className="text-[11px] text-red-700 font-medium">
                            Hủy kết bạn?
                          </span>
                          <button
                            type="button"
                            onClick={() => handleRemoveFriend(friend.id)}
                            className="px-2.5 py-1 rounded-md bg-red-600 text-white text-[11px] font-semibold hover:bg-red-700"
                          >
                            Xác nhận
                          </button>
                          <button
                            type="button"
                            onClick={() => setConfirmRemoveFriendId(null)}
                            className="px-2 py-1 rounded-md border border-[#D4E3D8] text-[11px] text-[#314E3F]"
                          >
                            Thôi
                          </button>
                        </div>
                      ) : (
                        <button
                          type="button"
                          onClick={() => setConfirmRemoveFriendId(friend.id)}
                          className="text-[11px] text-[#6D8B7A] hover:text-red-600"
                        >
                          Hủy kết bạn
                        </button>
                      )}

                      <button
                        type="button"
                        disabled={invitingFriendUid === friendUid || joining}
                        onClick={() => handleInviteFriend(friend)}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#165B3D] text-white text-xs font-semibold hover:bg-[#114830] disabled:opacity-50 whitespace-nowrap"
                      >
                        <CalendarClock className="w-3.5 h-3.5" />
                        {invitingFriendUid === friendUid ? 'Đang tạo phòng...' : 'Hẹn học lại'}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
