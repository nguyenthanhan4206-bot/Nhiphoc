import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  BookOpen,
  Camera,
  Check,
  CheckCheck,
  CheckCircle2,
  Clock,
  Copy,
  Eye,
  LogOut,
  Menu,
  MessageSquareText,
  Pause,
  Play,
  Plus,
  RotateCcw,
  Send,
  Sparkles,
  Sprout,
  Trash2,
  Trees,
  Users,
  Volume2,
  VolumeX,
  X,
} from 'lucide-react';
import {
  Assignment,
  FocusSession,
  Message,
  PublicUser,
  StudentProfile,
} from '../types';
import {
  createAssignment,
  getTreeStageLabel,
  logFocusSession,
  sendMessage,
  submitAssignmentPhoto,
} from '../services/nhiphocService';
import { formatCountdownMs, formatTimeAgoVi } from '../utils/imageCompress';
import { CameraCaptureModal } from './CameraCaptureModal';
import { DeleteAccountModal } from './DeleteAccountModal';
import { FOCUS_TREE_IMAGE_PATH, MascotAvatar, NhiphocRhythmMark } from './MascotAvatar';
import { StudyWithMeDateView } from './StudyWithMeDateView';

export type StudentTab = 'today' | 'extra' | 'focus_tree';

interface StudentDashboardProps {
  user: PublicUser;
  student: StudentProfile;
  assignments: Assignment[];
  focusSessions: FocusSession[];
  messages: Message[];
  unreadMessagesCount?: number;
  requestedTab?: { tab: StudentTab; nonce: number } | null;
  openMessagesNonce?: number;
  onMarkMessagesRead?: () => void;
  onNotify?: (toast: {
    category: 'assignment' | 'graded' | 'message' | 'info';
    title: string;
    message: string;
  }) => void;
  onSignOut: () => Promise<void>;
  onDeleteAccount: () => Promise<void>;
}

type StatusFilter = 'all' | 'pending' | 'submitted' | 'graded';

function playGentleChime() {
  try {
    const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    const now = ctx.currentTime;
    [523.25, 659.25, 783.99].forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now + idx * 0.14);
      gain.gain.setValueAtTime(0.001, now + idx * 0.14);
      gain.gain.exponentialRampToValueAtTime(0.12, now + idx * 0.14 + 0.04);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + idx * 0.14 + 0.8);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now + idx * 0.14);
      osc.stop(now + idx * 0.14 + 0.85);
    });
  } catch {
    // Ignore audio context block
  }
}

export const StudentDashboard: React.FC<StudentDashboardProps> = ({
  user,
  student,
  assignments,
  focusSessions,
  messages,
  unreadMessagesCount = 0,
  requestedTab,
  openMessagesNonce = 0,
  onMarkMessagesRead,
  onNotify,
  onSignOut,
  onDeleteAccount,
}) => {
  const [activeTab, setActiveTab] = useState<StudentTab>('today');
  const [focusMode, setFocusMode] = useState<'solo' | 'study_date'>('solo');
  const [filter, setFilter] = useState<StatusFilter>('all');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [nowMs, setNowMs] = useState(() => Date.now());

  // Messages drawer state
  const [showMessagesDrawer, setShowMessagesDrawer] = useState(false);
  const [msgInput, setMsgInput] = useState('');
  const [sendingMsg, setSendingMsg] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  // Camera modal & photo preview modal
  const [submittingAssignment, setSubmittingAssignment] = useState<Assignment | null>(null);
  const [previewPhoto, setPreviewPhoto] = useState<{ title: string; url: string } | null>(null);

  // Add self-practice assignment modal
  const [showAddModal, setShowAddModal] = useState(false);
  const [newSubject, setNewSubject] = useState('Toán học');
  const [newTitle, setNewTitle] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [addingTask, setAddingTask] = useState(false);

  // Focus Timer state
  const [presetMinutes, setPresetMinutes] = useState(25);
  const [secondsLeft, setSecondsLeft] = useState(25 * 60);
  const [timerRunning, setTimerRunning] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [focusNote, setFocusNote] = useState('');
  const [savingFocus, setSavingFocus] = useState(false);
  const [focusSavedBanner, setFocusSavedBanner] = useState<string | null>(null);
  const [treeImgError, setTreeImgError] = useState(false);

  const timerLoggedRef = useRef(false);

  const studentMessages = useMemo(
    () => messages.filter((m) => m.studentId === student.id),
    [messages, student.id],
  );

  useEffect(() => {
    if (requestedTab) {
      setActiveTab(requestedTab.tab);
      setFilter('all');
    }
  }, [requestedTab]);

  useEffect(() => {
    if (openMessagesNonce > 0) {
      setShowMessagesDrawer(true);
    }
  }, [openMessagesNonce]);

  useEffect(() => {
    if (showMessagesDrawer) {
      onMarkMessagesRead?.();
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [showMessagesDrawer, studentMessages.length, onMarkMessagesRead]);

  // Tick every second for 1-hour feedback countdown & Focus Timer
  useEffect(() => {
    const interval = setInterval(() => {
      setNowMs(Date.now());
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (!timerRunning) return;
    const id = setInterval(() => {
      setSecondsLeft((prev) => {
        if (prev <= 1) {
          setTimerRunning(false);
          if (soundEnabled) playGentleChime();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(id);
  }, [timerRunning, soundEnabled]);

  useEffect(() => {
    if (secondsLeft === 0 && !timerLoggedRef.current) {
      timerLoggedRef.current = true;
      handleSaveFocusSession(presetMinutes);
    }
  }, [secondsLeft]);

  const handleSelectPreset = (mins: number) => {
    setTimerRunning(false);
    setPresetMinutes(mins);
    setSecondsLeft(mins * 60);
    timerLoggedRef.current = false;
    setFocusSavedBanner(null);
  };

  const handleResetTimer = () => {
    setTimerRunning(false);
    setSecondsLeft(presetMinutes * 60);
    timerLoggedRef.current = false;
    setFocusSavedBanner(null);
  };

  const handleSaveFocusSession = async (minsOverride?: number) => {
    const elapsedSeconds = presetMinutes * 60 - secondsLeft;
    const minsToSave = minsOverride ?? Math.max(1, Math.round(elapsedSeconds / 60));
    setSavingFocus(true);
    try {
      await logFocusSession({
        student,
        uid: user.uid,
        durationMinutes: minsToSave,
        note: focusNote || `Phiên tập trung ${minsToSave} phút`,
      });
      setFocusSavedBanner(`Đã tưới thêm ${minsToSave} phút cho Cây tập trung của bạn.`);
      setFocusNote('');
      setSecondsLeft(presetMinutes * 60);
      setTimerRunning(false);
      timerLoggedRef.current = false;
    } finally {
      setSavingFocus(false);
    }
  };

  const handleCopyCode = () => {
    navigator.clipboard?.writeText(student.linkCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const handleCreateTask = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;
    setAddingTask(true);
    try {
      await createAssignment({
        student,
        createdBy: user.uid,
        type: activeTab === 'extra' ? 'extra' : 'today',
        subject: newSubject,
        title: newTitle,
        description: newDesc,
        dueLabel: activeTab === 'extra' ? 'Tự luyện bổ sung' : 'Hôm nay',
      });
      setNewTitle('');
      setNewDesc('');
      setShowAddModal(false);
    } finally {
      setAddingTask(false);
    }
  };

  const handleSendStudentMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!msgInput.trim()) return;
    setSendingMsg(true);
    try {
      await sendMessage({
        student,
        senderUid: user.uid,
        senderName: user.displayName,
        senderRole: 'student',
        content: msgInput,
      });
      setMsgInput('');
    } finally {
      setSendingMsg(false);
    }
  };

  const currentTypeAssignments = useMemo(() => {
    const targetType = activeTab === 'extra' ? 'extra' : 'today';
    return assignments.filter((a) => a.type === targetType);
  }, [assignments, activeTab]);

  const filteredAssignments = useMemo(() => {
    if (filter === 'all') return currentTypeAssignments;
    return currentTypeAssignments.filter((a) => a.status === filter);
  }, [currentTypeAssignments, filter]);

  const todayStats = useMemo(() => {
    const todayList = assignments.filter((a) => a.type === 'today');
    const submittedOrGraded = todayList.filter((a) => a.status !== 'pending').length;
    const graded = todayList.filter((a) => a.status === 'graded').length;
    return { total: todayList.length, submittedOrGraded, graded };
  }, [assignments]);

  const treeStage = getTreeStageLabel(student.focusMinutesTotal);
  const nextMilestone =
    student.focusMinutesTotal < 30
      ? 30
      : student.focusMinutesTotal < 90
        ? 90
        : student.focusMinutesTotal < 180
          ? 180
          : 300;
  const stageProgressPct = Math.min(100, Math.round((student.focusMinutesTotal / nextMilestone) * 100));

  const timerDisplay = `${String(Math.floor(secondsLeft / 60)).padStart(2, '0')}:${String(
    secondsLeft % 60,
  ).padStart(2, '0')}`;

  const navItems: Array<{ id: StudentTab; label: string; icon: React.FC<{ className?: string }> }> = [
    { id: 'today', label: 'Bài tập hôm nay', icon: BookOpen },
    { id: 'extra', label: 'Bài tập bổ sung', icon: Sparkles },
    { id: 'focus_tree', label: 'Cây tập trung', icon: Trees },
  ];

  const renderSidebarContent = () => (
    <div className="flex flex-col h-full justify-between p-5">
      <div className="space-y-6">
        {/* Brand Header with Mascot */}
        <div className="flex items-center gap-3 pb-4 border-b border-[#DCE8DF]">
          <MascotAvatar size="md" />
          <div className="min-w-0">
            <p className="text-lg font-bold tracking-tight text-[#112A1E] leading-tight">
              Nhiphoc
            </p>
            <p className="text-xs text-[#4B6859] truncate">
              {student.studentName} · {student.grade}
            </p>
          </div>
        </div>

        {/* 3 Navigation Items */}
        <nav className="space-y-1.5" aria-label="Menu học sinh">
          {navItems.map((item) => {
            const Icon = item.icon;
            const active = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => {
                  setActiveTab(item.id);
                  setFilter('all');
                  setMobileMenuOpen(false);
                }}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-semibold transition-colors whitespace-nowrap ${
                  active
                    ? 'bg-[#165B3D] text-white'
                    : 'text-[#314E3F] hover:bg-[#E7F2EA] hover:text-[#112A1E]'
                }`}
              >
                <Icon className="w-4 h-4 shrink-0" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Link Code Box for Parent / Assistant */}
        <div className="rounded-xl border border-[#D4E3D8] bg-[#F5FAF6] p-3.5 space-y-2">
          <p className="text-xs font-semibold text-[#165B3D]">Mã kết nối gia đình</p>
          <p className="text-[11px] text-[#4B6859] leading-relaxed">
            Gửi mã này cho Cha mẹ hoặc Trợ lý để kết nối cùng theo dõi bài tập.
          </p>
          <button
            type="button"
            onClick={handleCopyCode}
            className="w-full flex items-center justify-between px-3 py-2 rounded-lg bg-white border border-[#CFE0D4] text-xs font-mono font-semibold text-[#112A1E] hover:border-[#165B3D] transition-colors"
          >
            <span>{student.linkCode}</span>
            <span className="inline-flex items-center gap-1 text-[#165B3D] font-sans">
              <Copy className="w-3.5 h-3.5" />
              {copiedCode ? 'Đã chép' : 'Sao chép'}
            </span>
          </button>
        </div>
      </div>

      {/* Footer Account */}
      <div className="pt-4 border-t border-[#DCE8DF] space-y-3">
        <div className="text-xs text-[#4B6859]">
          <p className="font-semibold text-[#112A1E] truncate">{user.displayName}</p>
          <p className="truncate">
            Trợ lý: {student.assistantOnline ? 'Đang trực tuyến' : 'Ngoại tuyến (nhận xét sau 1h)'}
          </p>
        </div>
        <button
          type="button"
          onClick={onSignOut}
          className="w-full flex items-center justify-center gap-2 px-3.5 py-2 rounded-xl border border-[#D4E3D8] text-xs font-semibold text-[#314E3F] hover:bg-[#EDF5EF] transition-colors"
        >
          <LogOut className="w-3.5 h-3.5" />
          Đăng xuất
        </button>
        <button
          type="button"
          onClick={() => setShowDeleteModal(true)}
          className="w-full flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-lg text-[11px] font-medium text-[#789484] hover:text-red-700 hover:bg-red-50 transition-colors"
        >
          <Trash2 className="w-3 h-3" />
          Xóa tài khoản
        </button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-[#F6FAF7] text-[#112A1E] flex">
      {/* Desktop Left Sidebar */}
      <aside className="hidden lg:block w-[264px] shrink-0 bg-white border-r border-[#DCE8DF] sticky top-0 h-screen">
        {renderSidebarContent()}
      </aside>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-[#112A1E]/40"
            onClick={() => setMobileMenuOpen(false)}
          />
          <aside className="relative w-72 max-w-[85vw] bg-white h-full border-r border-[#DCE8DF] z-10">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(false)}
              className="absolute top-4 right-4 p-2 rounded-lg text-[#4B6859] hover:bg-[#EDF5EF]"
              aria-label="Đóng menu"
            >
              <X className="w-5 h-5" />
            </button>
            {renderSidebarContent()}
          </aside>
        </div>
      )}

      {/* Main Content */}
      <div className="flex-1 min-w-0 flex flex-col">
        {/* Workspace Top Bar */}
        <header className="bg-white/90 backdrop-blur-sm border-b border-[#DCE8DF] sticky top-0 z-20">
          <div className="max-w-5xl mx-auto px-5 sm:px-8 py-3.5 flex items-center justify-between gap-4">
            <div className="flex items-center gap-3 min-w-0">
              <button
                type="button"
                onClick={() => setMobileMenuOpen(true)}
                className="lg:hidden p-2 -ml-2 rounded-lg text-[#112A1E] hover:bg-[#EDF5EF]"
                aria-label="Mở menu"
              >
                <Menu className="w-5 h-5" />
              </button>
              <div className="min-w-0">
                <p className="text-xs text-[#4B6859] truncate">
                  Không gian học sinh · {student.grade}
                </p>
                <h1 className="text-lg font-bold text-[#112A1E] truncate">
                  {navItems.find((n) => n.id === activeTab)?.label}
                </h1>
              </div>
            </div>

            <div className="flex items-center gap-2.5 shrink-0">
              <button
                type="button"
                onClick={() => {
                  setActiveTab('focus_tree');
                  setFocusMode('study_date');
                  setFilter('all');
                }}
                className={`inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border text-xs font-semibold transition-colors whitespace-nowrap ${
                  activeTab === 'focus_tree' && focusMode === 'study_date'
                    ? 'border-[#165B3D] bg-[#165B3D] text-white'
                    : 'border-[#D4E3D8] bg-white text-[#114B32] hover:bg-[#EDF5EF]'
                }`}
              >
                <Users className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">StudyWithMe Date</span>
                <span className="sm:hidden">Date</span>
              </button>
              <button
                type="button"
                onClick={() => setShowMessagesDrawer(true)}
                className={`inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border text-xs font-semibold transition-colors whitespace-nowrap ${
                  unreadMessagesCount > 0
                    ? 'border-[#165B3D] bg-[#E7F4EB] text-[#114B32]'
                    : 'border-[#D4E3D8] bg-white text-[#314E3F] hover:bg-[#EDF5EF]'
                }`}
              >
                <MessageSquareText className="w-3.5 h-3.5" />
                <span>
                  Tin nhắn trợ lý
                  {unreadMessagesCount > 0
                    ? ` (${unreadMessagesCount} mới)`
                    : studentMessages.length > 0
                      ? ` (${studentMessages.length})`
                      : ''}
                </span>
              </button>
              {activeTab !== 'focus_tree' && (
                <button
                  type="button"
                  onClick={() => setShowAddModal(true)}
                  className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#165B3D] text-white text-xs font-semibold hover:bg-[#114830] transition-colors whitespace-nowrap"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Thêm bài tự luyện</span>
                  <span className="sm:hidden">Thêm bài</span>
                </button>
              )}
            </div>
          </div>
        </header>

        <main className="flex-1 max-w-5xl w-full mx-auto px-5 sm:px-8 py-7 space-y-6">
          {/* Nhiphoc Student Rhythm Banner */}
          <section className="rounded-2xl bg-[#114B32] text-white p-5 sm:p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-5">
            <div className="flex items-center gap-4">
              <MascotAvatar size="lg" className="border-2 border-[#A7D7B8]" />
              <div className="space-y-1">
                <div className="flex items-center gap-2.5">
                  <NhiphocRhythmMark dark />
                  <span className="text-xs font-medium text-[#CBEAD4]">
                    Nhịp học hôm nay
                  </span>
                </div>
                <h2 className="text-lg sm:text-xl font-bold text-white">
                  Chào {student.studentName}, cùng giữ nhịp tập trung nhé!
                </h2>
              </div>
            </div>

            <div className="flex items-center gap-6 shrink-0 border-t sm:border-t-0 sm:border-l border-white/15 pt-3 sm:pt-0 sm:pl-6 tabular-nums">
              <div>
                <p className="text-[11px] text-[#CBEAD4]">Cây tập trung</p>
                <p className="text-base font-bold text-white">{student.focusMinutesTotal} phút</p>
              </div>
              <div>
                <p className="text-[11px] text-[#CBEAD4]">Chuỗi ngày</p>
                <p className="text-base font-bold text-[#A7D7B8]">{student.streakDays} ngày</p>
              </div>
            </div>
          </section>

          {activeTab !== 'focus_tree' ? (
            <>
              {/* Overview Metrics Strip (Clean hairline, tabular-nums, zero pills) */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="p-4 rounded-xl bg-white border border-[#DCE8DF]">
                  <p className="text-xs text-[#4B6859]">Tiến độ hôm nay</p>
                  <p className="text-2xl font-bold text-[#112A1E] mt-1 tabular-nums">
                    {todayStats.submittedOrGraded}/{todayStats.total} bài đã nộp
                  </p>
                </div>
                <div className="p-4 rounded-xl bg-white border border-[#DCE8DF]">
                  <p className="text-xs text-[#4B6859]">Trợ lý đã chấm xong</p>
                  <p className="text-2xl font-bold text-[#165B3D] mt-1 tabular-nums">
                    {todayStats.graded}/{todayStats.total} bài hoàn tất
                  </p>
                </div>
                <div className="p-4 rounded-xl bg-white border border-[#DCE8DF]">
                  <p className="text-xs text-[#4B6859]">Trạng thái trợ lý</p>
                  <p className="text-base font-bold text-[#112A1E] mt-2">
                    {student.assistantOnline
                      ? 'Đang trực · Nhận xét ngay'
                      : 'Ngoại tuyến · Nhận xét sau 1h'}
                  </p>
                </div>
              </div>

              {/* Interactive Filter Segmented Control */}
              <div className="flex flex-wrap items-center justify-between gap-4">
                <div className="inline-flex items-center gap-1 p-1 rounded-xl bg-[#E8F2EB] border border-[#D4E3D8]">
                  {(
                    [
                      { id: 'all', label: 'Tất cả' },
                      { id: 'pending', label: 'Chưa nộp' },
                      { id: 'submitted', label: 'Đã nộp' },
                      { id: 'graded', label: 'Đã chấm xong' },
                    ] as const
                  ).map((tab) => (
                    <button
                      key={tab.id}
                      type="button"
                      onClick={() => setFilter(tab.id)}
                      className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap ${
                        filter === tab.id
                          ? 'bg-white text-[#112A1E] shadow-sm'
                          : 'text-[#4B6859] hover:text-[#112A1E]'
                      }`}
                    >
                      {tab.label}
                    </button>
                  ))}
                </div>

                <p className="text-xs text-[#4B6859] tabular-nums">
                  Hiển thị {filteredAssignments.length} bài tập
                </p>
              </div>

              {/* Assignment Checklist */}
              {filteredAssignments.length === 0 ? (
                <div className="rounded-2xl border border-[#DCE8DF] bg-white p-10 text-center space-y-3">
                  <div className="w-12 h-12 rounded-xl bg-[#EBF4EE] text-[#165B3D] flex items-center justify-center mx-auto">
                    <BookOpen className="w-6 h-6" />
                  </div>
                  <h3 className="text-base font-bold text-[#112A1E]">
                    Chưa có bài tập nào trong mục này
                  </h3>
                  <p className="text-sm text-[#4B6859] max-w-md mx-auto">
                    Trợ lý sẽ giao bài mới tại đây, hoặc bạn có thể chủ động thêm một bài tự luyện
                    để chụp ảnh và lưu tiến độ.
                  </p>
                  <button
                    type="button"
                    onClick={() => setShowAddModal(true)}
                    className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-[#165B3D] text-white text-xs font-semibold hover:bg-[#114830] transition-colors"
                  >
                    <Plus className="w-4 h-4" />
                    Thêm bài tập mới
                  </button>
                </div>
              ) : (
                <div className="space-y-4">
                  {filteredAssignments.map((item) => {
                    const isSubmitted = item.status === 'submitted';
                    const isGraded = item.status === 'graded';
                    const feedbackUnlocked =
                      isSubmitted &&
                      (student.assistantOnline ||
                        (item.feedbackScheduledAtMs > 0 && nowMs >= item.feedbackScheduledAtMs));

                    return (
                      <article
                        key={item.id}
                        className="rounded-2xl border border-[#DCE8DF] bg-white p-5 sm:p-6 space-y-4"
                      >
                        <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                          <div className="flex items-start gap-3.5 min-w-0">
                            {/* Dual-Tick To-Do Status Control */}
                            <div
                              className={`w-7 h-7 rounded-lg border flex items-center justify-center shrink-0 mt-0.5 ${
                                isGraded
                                  ? 'bg-[#165B3D] border-[#165B3D] text-white'
                                  : isSubmitted
                                    ? 'bg-[#E3F3E8] border-[#2E8B57] text-[#165B3D]'
                                    : 'bg-[#F8FBF9] border-[#C8DDD0] text-[#789484]'
                              }`}
                              title={
                                isGraded
                                  ? 'Đã chấm xong'
                                  : isSubmitted
                                    ? 'Đã nộp bài'
                                    : 'Chưa nộp'
                              }
                            >
                              {isGraded ? (
                                <CheckCheck className="w-4 h-4" />
                              ) : isSubmitted ? (
                                <Check className="w-4 h-4" />
                              ) : (
                                <span className="w-2 h-2 rounded-full bg-[#CBDCD1]" />
                              )}
                            </div>

                            <div className="min-w-0 space-y-1">
                              {/* Unboxed metadata with typographic separators */}
                              <div className="flex flex-wrap items-center gap-2 text-xs text-[#4B6859]">
                                <span className="font-semibold text-[#165B3D]">{item.subject}</span>
                                <span aria-hidden="true">·</span>
                                <span>{item.dueLabel}</span>
                                <span aria-hidden="true">·</span>
                                <span
                                  className={
                                    isGraded
                                      ? 'font-semibold text-[#165B3D]'
                                      : isSubmitted
                                        ? 'font-semibold text-[#2E8B57]'
                                        : 'text-[#5C7A69]'
                                  }
                                >
                                  {isGraded
                                    ? 'Tick: Đã chấm xong'
                                    : isSubmitted
                                      ? 'Tick: Đã nộp (chờ chấm chi tiết)'
                                      : 'Chưa nộp'}
                                </span>
                              </div>

                              <h3 className="text-base font-bold text-[#112A1E]">
                                {item.title}
                              </h3>

                              {item.description && (
                                <p className="text-sm text-[#4B6859] leading-relaxed">
                                  {item.description}
                                </p>
                              )}
                            </div>
                          </div>

                          {/* Action Buttons */}
                          <div className="flex items-center gap-2.5 shrink-0 pl-10 sm:pl-0">
                            {item.photoDataUrl && (
                              <button
                                type="button"
                                onClick={() =>
                                  setPreviewPhoto({ title: item.title, url: item.photoDataUrl })
                                }
                                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-[#D4E3D8] bg-[#F8FBF9] text-xs font-semibold text-[#112A1E] hover:bg-[#EDF5EF] transition-colors whitespace-nowrap"
                              >
                                <Eye className="w-3.5 h-3.5" />
                                Xem ảnh đã nộp
                              </button>
                            )}

                            {!isGraded && (
                              <button
                                type="button"
                                onClick={() => setSubmittingAssignment(item)}
                                className={`inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap ${
                                  isSubmitted
                                    ? 'border border-[#165B3D] text-[#165B3D] hover:bg-[#EBF4EE]'
                                    : 'bg-[#165B3D] text-white hover:bg-[#114830]'
                                }`}
                              >
                                <Camera className="w-3.5 h-3.5" />
                                {isSubmitted ? 'Chụp lại ảnh' : 'Chụp ảnh nộp bài'}
                              </button>
                            )}
                          </div>
                        </div>

                        {/* Submitted Status & 1h / Instant Feedback Box */}
                        {isSubmitted && (
                          <div className="ml-10 rounded-xl border border-[#D4E3D8] bg-[#F4FAF6] p-4 space-y-2">
                            <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                              <span className="font-semibold text-[#165B3D] inline-flex items-center gap-1.5">
                                <CheckCircle2 className="w-4 h-4 text-[#2E8B57]" />
                                Đã tích hoàn thành nộp bài ({formatTimeAgoVi(item.submittedAtMs)})
                              </span>
                              {!feedbackUnlocked && (
                                <span className="font-mono text-[#4B6859] inline-flex items-center gap-1.5 tabular-nums">
                                  <Clock className="w-3.5 h-3.5" />
                                  Nhận xét mở sau: {formatCountdownMs(item.feedbackScheduledAtMs, nowMs)}
                                </span>
                              )}
                            </div>

                            {feedbackUnlocked ? (
                              <p className="text-sm text-[#1F3D2E] leading-relaxed">
                                {item.instantFeedbackNote ||
                                  'Bài nộp đã được chuyển tới trợ lý. Trợ lý đang rà soát từng câu để gửi chấm điểm hoàn tất.'}
                              </p>
                            ) : (
                              <p className="text-xs text-[#4B6859] leading-relaxed">
                                Trợ lý hiện đang ngoại tuyến. Bạn vẫn đã được tick Đã nộp trong
                                todolist; nhận xét sơ bộ sẽ hiển thị sau 1 giờ hoặc ngay khi trợ lý
                                trực tuyến trở lại.
                              </p>
                            )}
                          </div>
                        )}

                        {/* Graded Feedback Box */}
                        {isGraded && (
                          <div className="ml-10 rounded-xl border border-[#BFE0C9] bg-[#EBF6EE] p-4 space-y-2">
                            <div className="flex flex-wrap items-center justify-between gap-2">
                              <span className="text-xs font-bold text-[#165B3D] inline-flex items-center gap-1.5">
                                <MessageSquareText className="w-4 h-4" />
                                Nhận xét từ trợ lý · Đã chấm xong
                              </span>
                              <span className="text-xs font-bold text-[#112A1E] tabular-nums">
                                Kết quả: {item.scoreLabel || 'Hoàn thành tốt'}
                              </span>
                            </div>
                            <p className="text-sm text-[#112A1E] leading-relaxed">
                              {item.assistantFeedback}
                            </p>
                          </div>
                        )}
                      </article>
                    );
                  })}
                </div>
              )}
            </>
          ) : (
            /* Section 3: Cây tập trung & StudyWithMe Date */
            <div className="space-y-6">
              <div className="flex flex-wrap items-center justify-between gap-4">
                <div className="inline-flex items-center gap-1 p-1 rounded-xl bg-[#E7F2EA] border border-[#CFE3D5]">
                  <button
                    type="button"
                    onClick={() => setFocusMode('solo')}
                    className={`px-4 py-2 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap ${
                      focusMode === 'solo'
                        ? 'bg-[#165B3D] text-white'
                        : 'text-[#314E3F] hover:text-[#112A1E]'
                    }`}
                  >
                    Cây tập trung cá nhân
                  </button>
                  <button
                    type="button"
                    onClick={() => setFocusMode('study_date')}
                    className={`px-4 py-2 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap ${
                      focusMode === 'study_date'
                        ? 'bg-[#165B3D] text-white'
                        : 'text-[#314E3F] hover:text-[#112A1E]'
                    }`}
                  >
                    StudyWithMe Date (Sinh viên)
                  </button>
                </div>
                <p className="text-xs text-[#4B6859]">
                  {focusMode === 'study_date'
                    ? 'Ghép đôi học tập từ xa 1-1 cùng sinh viên khác'
                    : 'Tự đếm Pomodoro và nuôi lớn Cây tập trung'}
                </p>
              </div>

              {focusMode === 'study_date' ? (
                <StudyWithMeDateView user={user} student={student} onNotify={onNotify} />
              ) : (
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
              {/* Left: Tree Visual & Growth Progress */}
              <div className="lg:col-span-6 rounded-2xl border border-[#DCE8DF] bg-white p-6 space-y-5">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <p className="text-xs text-[#4B6859]">Cấp độ hiện tại</p>
                    <h2 className="text-xl font-bold text-[#112A1E]">
                      Cấp {treeStage.level} · {treeStage.label}
                    </h2>
                  </div>
                  <div className="text-right tabular-nums">
                    <p className="text-xs text-[#4B6859]">Tổng tích lũy</p>
                    <p className="text-lg font-bold text-[#165B3D]">
                      {student.focusMinutesTotal} phút
                    </p>
                  </div>
                </div>

                <div className="rounded-xl border border-[#DCE8DF] bg-[#F3F8F4] overflow-hidden aspect-square max-h-[340px] w-full flex items-center justify-center">
                  {!treeImgError ? (
                    <img
                      src={FOCUS_TREE_IMAGE_PATH}
                      alt="Cây tập trung Nhiphoc xanh tốt"
                      referrerPolicy="no-referrer"
                      onError={() => setTreeImgError(true)}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="p-8 text-center text-[#165B3D] space-y-2">
                      <Sprout className="w-12 h-12 mx-auto" />
                      <p className="text-sm font-semibold">{treeStage.label}</p>
                    </div>
                  )}
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs text-[#4B6859] tabular-nums">
                    <span>Tiến độ lên cấp tiếp theo</span>
                    <span>
                      {student.focusMinutesTotal}/{nextMilestone} phút ({stageProgressPct}%)
                    </span>
                  </div>
                  <div className="h-2.5 w-full rounded-full bg-[#E6F0E9] overflow-hidden">
                    <div
                      className="h-full bg-[#165B3D] rounded-full transition-all duration-300"
                      style={{ width: `${stageProgressPct}%` }}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 pt-2 border-t border-[#E5EFE8]">
                  <div>
                    <p className="text-xs text-[#4B6859]">Chuỗi ngày tập trung</p>
                    <p className="text-lg font-bold text-[#112A1E] tabular-nums">
                      {student.streakDays} ngày
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-[#4B6859]">Số phiên đã lưu</p>
                    <p className="text-lg font-bold text-[#112A1E] tabular-nums">
                      {focusSessions.length} phiên
                    </p>
                  </div>
                </div>
              </div>

              {/* Right: Interactive Focus Timer + History */}
              <div className="lg:col-span-6 space-y-6">
                <div className="rounded-2xl border border-[#DCE8DF] bg-white p-6 space-y-6">
                  <div className="flex items-center justify-between gap-3">
                    <div>
                      <p className="text-xs text-[#4B6859]">Đồng hồ Pomodoro</p>
                      <h3 className="text-lg font-bold text-[#112A1E]">
                        Bấm giờ nuôi Cây tập trung
                      </h3>
                    </div>
                    <button
                      type="button"
                      onClick={() => setSoundEnabled((v) => !v)}
                      className="p-2 rounded-lg border border-[#DCE8DF] text-[#4B6859] hover:text-[#112A1E] hover:bg-[#F3F8F4] transition-colors"
                      aria-label={soundEnabled ? 'Tắt chuông báo' : 'Bật chuông báo'}
                      title={soundEnabled ? 'Chuông báo đang bật' : 'Chuông báo đang tắt'}
                    >
                      {soundEnabled ? (
                        <Volume2 className="w-4 h-4" />
                      ) : (
                        <VolumeX className="w-4 h-4" />
                      )}
                    </button>
                  </div>

                  {/* Preset selector */}
                  <div className="grid grid-cols-4 gap-2 p-1 rounded-xl bg-[#EEF5F0] border border-[#DCE8DF]">
                    {[5, 15, 25, 45].map((mins) => (
                      <button
                        key={mins}
                        type="button"
                        onClick={() => handleSelectPreset(mins)}
                        className={`py-2 rounded-lg text-xs font-semibold tabular-nums transition-colors ${
                          presetMinutes === mins
                            ? 'bg-white text-[#112A1E] shadow-sm'
                            : 'text-[#4B6859] hover:text-[#112A1E]'
                        }`}
                      >
                        {mins} phút
                      </button>
                    ))}
                  </div>

                  {/* Big Tabular Timer Display */}
                  <div className="py-6 rounded-2xl bg-[#F4FAF6] border border-[#DCE8DF] text-center space-y-2">
                    <p className="font-mono text-5xl sm:text-6xl font-bold text-[#165B3D] tracking-tight tabular-nums">
                      {timerDisplay}
                    </p>
                    <p className="text-xs text-[#4B6859]">
                      {timerRunning
                        ? 'Cây đang hấp thụ ánh sáng — giữ tập trung nhé!'
                        : 'Sẵn sàng cho phiên học sâu không xao nhãng'}
                    </p>
                  </div>

                  <div>
                    <label
                      htmlFor="focus-note"
                      className="block text-xs font-semibold text-[#112A1E] mb-1.5"
                    >
                      Mục tiêu phiên học này
                    </label>
                    <input
                      id="focus-note"
                      type="text"
                      maxLength={200}
                      value={focusNote}
                      onChange={(e) => setFocusNote(e.target.value)}
                      placeholder="Ví dụ: Làm trọn bộ 5 bài Toán phương trình"
                      className="w-full rounded-xl border border-[#D4E3D8] px-3.5 py-2.5 text-sm text-[#112A1E] focus:outline-none focus:ring-2 focus:ring-[#165B3D]/25 focus:border-[#165B3D]"
                    />
                  </div>

                  <div className="flex flex-wrap items-center gap-3">
                    <button
                      type="button"
                      onClick={() => {
                        setFocusSavedBanner(null);
                        setTimerRunning((r) => !r);
                      }}
                      className="flex-1 inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-[#165B3D] text-white text-sm font-semibold hover:bg-[#114830] transition-colors whitespace-nowrap"
                    >
                      {timerRunning ? (
                        <>
                          <Pause className="w-4 h-4" />
                          Tạm dừng
                        </>
                      ) : (
                        <>
                          <Play className="w-4 h-4" />
                          Bắt đầu tập trung
                        </>
                      )}
                    </button>

                    <button
                      type="button"
                      onClick={handleResetTimer}
                      className="inline-flex items-center justify-center gap-1.5 px-4 py-3 rounded-xl border border-[#D4E3D8] text-sm font-medium text-[#314E3F] hover:bg-[#EDF5EF] transition-colors whitespace-nowrap"
                    >
                      <RotateCcw className="w-4 h-4" />
                      Đặt lại
                    </button>

                    {presetMinutes * 60 - secondsLeft >= 60 && (
                      <button
                        type="button"
                        disabled={savingFocus}
                        onClick={() => handleSaveFocusSession()}
                        className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-[#E3F3E8] border border-[#BFE0C9] text-xs font-semibold text-[#165B3D] hover:bg-[#D5ECDC] transition-colors"
                      >
                        <Sprout className="w-4 h-4" />
                        {savingFocus ? 'Đang lưu...' : 'Lưu số phút đã tập trung vào Cây'}
                      </button>
                    )}
                  </div>

                  {focusSavedBanner && (
                    <p className="text-xs font-semibold text-[#165B3D] bg-[#EBF6EE] border border-[#BFE0C9] rounded-xl px-4 py-3">
                      {focusSavedBanner}
                    </p>
                  )}
                </div>

                {/* Recent Focus Log */}
                <div className="rounded-2xl border border-[#DCE8DF] bg-white p-6 space-y-4">
                  <h3 className="text-base font-bold text-[#112A1E]">
                    Nhật ký tưới cây gần đây
                  </h3>
                  {focusSessions.length === 0 ? (
                    <p className="text-sm text-[#4B6859]">
                      Hoàn thành phiên tập trung đầu tiên để ghi nhận thành tích tại đây.
                    </p>
                  ) : (
                    <div className="divide-y divide-[#E9F1EC]">
                      {focusSessions.slice(0, 6).map((s) => (
                        <div
                          key={s.id}
                          className="py-3 flex items-center justify-between gap-4 text-sm"
                        >
                          <div className="min-w-0">
                            <p className="font-semibold text-[#112A1E] truncate">{s.note}</p>
                            <p className="text-xs text-[#4B6859]">{s.treeStage}</p>
                          </div>
                          <span className="font-mono font-semibold text-[#165B3D] tabular-nums shrink-0">
                            +{s.durationMinutes} phút
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
              )}
            </div>
          )}
        </main>
      </div>

      {/* Camera / Upload Modal */}
      {submittingAssignment && (
        <CameraCaptureModal
          assignmentTitle={submittingAssignment.title}
          initialNote={submittingAssignment.studentNote}
          onClose={() => setSubmittingAssignment(null)}
          onSubmit={async (photoDataUrl, studentNote) => {
            await submitAssignmentPhoto({
              assignmentId: submittingAssignment.id,
              photoDataUrl,
              studentNote,
              assistantOnline: student.assistantOnline,
            });
          }}
        />
      )}

      {/* Photo Preview Lightbox */}
      {previewPhoto && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-[#112A1E]/60 p-4"
          onClick={() => setPreviewPhoto(null)}
        >
          <div
            className="max-w-2xl w-full bg-white rounded-2xl border border-[#D4E3D8] overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="px-5 py-3.5 border-b border-[#E5EFE8] flex items-center justify-between">
              <p className="text-sm font-bold text-[#112A1E] truncate">{previewPhoto.title}</p>
              <button
                type="button"
                onClick={() => setPreviewPhoto(null)}
                className="p-1.5 rounded-lg text-[#4B6859] hover:bg-[#EDF5EF]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-4 bg-[#F5FAF6]">
              <img
                src={previewPhoto.url}
                alt={previewPhoto.title}
                className="max-h-[70vh] mx-auto rounded-lg object-contain"
              />
            </div>
          </div>
        </div>
      )}

      {/* Add Self-Practice Task Modal */}
      {showAddModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-[#112A1E]/45 p-4"
          role="dialog"
          aria-modal="true"
        >
          <div className="w-full max-w-md bg-white rounded-2xl border border-[#D4E3D8] p-6 space-y-5">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-bold text-[#112A1E]">
                Thêm {activeTab === 'extra' ? 'bài tập bổ sung' : 'bài tập hôm nay'}
              </h3>
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="p-1.5 rounded-lg text-[#4B6859] hover:bg-[#EDF5EF]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateTask} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-[#112A1E] mb-1.5">
                  Môn học
                </label>
                <select
                  value={newSubject}
                  onChange={(e) => setNewSubject(e.target.value)}
                  className="w-full rounded-xl border border-[#D4E3D8] px-3.5 py-2.5 text-sm text-[#112A1E] bg-white focus:outline-none focus:ring-2 focus:ring-[#165B3D]/25"
                >
                  <option value="Toán học">Toán học</option>
                  <option value="Ngữ văn">Ngữ văn</option>
                  <option value="Tiếng Anh">Tiếng Anh</option>
                  <option value="Khoa học">Khoa học</option>
                  <option value="Tổng hợp">Tổng hợp</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#112A1E] mb-1.5">
                  Tên bài tập
                </label>
                <input
                  type="text"
                  required
                  maxLength={120}
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="Ví dụ: Ôn tập 10 câu trắc nghiệm hình học"
                  className="w-full rounded-xl border border-[#D4E3D8] px-3.5 py-2.5 text-sm text-[#112A1E] focus:outline-none focus:ring-2 focus:ring-[#165B3D]/25"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#112A1E] mb-1.5">
                  Mô tả ngắn
                </label>
                <textarea
                  rows={3}
                  maxLength={800}
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                  placeholder="Ghi chú trang sách hoặc yêu cầu cần hoàn thành..."
                  className="w-full rounded-xl border border-[#D4E3D8] px-3.5 py-2.5 text-sm text-[#112A1E] focus:outline-none focus:ring-2 focus:ring-[#165B3D]/25"
                />
              </div>

              <div className="flex justify-end gap-2.5 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-lg text-xs font-semibold text-[#4B6859] hover:bg-[#EDF5EF]"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  disabled={addingTask}
                  className="px-4 py-2 rounded-lg bg-[#165B3D] text-white text-xs font-semibold hover:bg-[#114830] disabled:opacity-50"
                >
                  {addingTask ? 'Đang tạo...' : 'Lưu bài tập'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Messages Slide-over Drawer */}
      {showMessagesDrawer && (
        <div
          className="fixed inset-0 z-50 flex justify-end bg-[#112A1E]/45"
          onClick={() => setShowMessagesDrawer(false)}
          role="dialog"
          aria-modal="true"
          aria-label="Tin nhắn với trợ lý"
        >
          <div
            className="w-full max-w-md bg-white h-full border-l border-[#DCE8DF] flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="px-5 py-4 border-b border-[#DCE8DF] flex items-center justify-between gap-3">
              <div className="min-w-0">
                <h3 className="text-base font-bold text-[#112A1E]">
                  Tin nhắn với Trợ lý
                </h3>
                <p className="text-xs text-[#4B6859] truncate">
                  {student.assistantOnline
                    ? 'Trợ lý đang trực tuyến · phản hồi nhanh'
                    : 'Gửi câu hỏi hoặc xem nhận xét từ trợ lý & gia đình'}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setShowMessagesDrawer(false)}
                className="p-2 rounded-lg text-[#4B6859] hover:bg-[#EDF5EF]"
                aria-label="Đóng hộp tin nhắn"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-5 space-y-3 bg-[#F9FCFA]">
              {studentMessages.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center px-4 py-12 space-y-2">
                  <MessageSquareText className="w-8 h-8 text-[#96B5A3]" />
                  <p className="text-sm font-semibold text-[#112A1E]">Chưa có tin nhắn nào</p>
                  <p className="text-xs text-[#4B6859] leading-relaxed">
                    Khi Trợ lý gửi lời nhắc hoặc phản hồi về bài làm, thông báo đẩy sẽ hiện ngay trên màn hình và lưu tại đây.
                  </p>
                </div>
              ) : (
                studentMessages.map((m) => {
                  const mine = m.senderUid === user.uid;
                  const roleLabel =
                    m.senderRole === 'assistant'
                      ? 'Trợ lý'
                      : m.senderRole === 'parent'
                        ? 'Phụ huynh'
                        : 'Bạn';
                  return (
                    <div
                      key={m.id}
                      className={`flex flex-col ${mine ? 'items-end' : 'items-start'}`}
                    >
                      <div
                        className={`max-w-[85%] rounded-2xl px-4 py-2.5 text-sm leading-relaxed ${
                          mine
                            ? 'bg-[#165B3D] text-white'
                            : 'bg-white border border-[#DCE8DF] text-[#112A1E]'
                        }`}
                      >
                        <p
                          className={`text-[11px] font-semibold mb-1 ${
                            mine ? 'text-[#CBEAD4]' : 'text-[#4B6859]'
                          }`}
                        >
                          {mine ? 'Bạn' : `${roleLabel} · ${m.senderName}`}
                        </p>
                        <p className="whitespace-pre-wrap break-words">{m.content}</p>
                      </div>
                      <span className="text-[11px] text-[#6D8B7A] mt-1 px-1">
                        {formatTimeAgoVi(m.createdAt?.toMillis?.() || nowMs)}
                      </span>
                    </div>
                  );
                })
              )}
              <div ref={messagesEndRef} />
            </div>

            <form
              onSubmit={handleSendStudentMessage}
              className="p-4 border-t border-[#DCE8DF] bg-white flex items-center gap-2.5"
            >
              <input
                type="text"
                maxLength={1000}
                value={msgInput}
                onChange={(e) => setMsgInput(e.target.value)}
                placeholder="Nhắn hỏi trợ lý về bài tập..."
                className="flex-1 rounded-xl border border-[#D4E3D8] px-3.5 py-2.5 text-sm text-[#112A1E] focus:outline-none focus:ring-2 focus:ring-[#165B3D]/25 focus:border-[#165B3D]"
              />
              <button
                type="submit"
                disabled={sendingMsg || !msgInput.trim()}
                className="inline-flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl bg-[#165B3D] text-white text-xs font-semibold hover:bg-[#114830] disabled:opacity-50 shrink-0"
              >
                <Send className="w-3.5 h-3.5" />
                Gửi
              </button>
            </form>
          </div>
        </div>
      )}

      {showDeleteModal && (
        <DeleteAccountModal
          displayName={user.displayName}
          onClose={() => setShowDeleteModal(false)}
          onConfirmDelete={onDeleteAccount}
        />
      )}
    </div>
  );
};
