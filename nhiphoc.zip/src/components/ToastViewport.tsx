import React, { useEffect } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { Bell, BookOpen, CheckCheck, MessageSquareText, X } from 'lucide-react';

export type ToastCategory = 'assignment' | 'graded' | 'message' | 'info';

export interface NhiphocToast {
  id: string;
  category: ToastCategory;
  title: string;
  message: string;
  actionLabel?: string;
  onAction?: () => void;
  createdAtMs: number;
}

interface ToastViewportProps {
  toasts: NhiphocToast[];
  dark?: boolean;
  onDismiss: (id: string) => void;
}

const ToastItem: React.FC<{
  toast: NhiphocToast;
  dark: boolean;
  onDismiss: (id: string) => void;
}> = ({ toast, dark, onDismiss }) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onDismiss(toast.id);
    }, 6500);
    return () => clearTimeout(timer);
  }, [toast.id, onDismiss]);

  const Icon =
    toast.category === 'assignment'
      ? BookOpen
      : toast.category === 'graded'
        ? CheckCheck
        : toast.category === 'message'
          ? MessageSquareText
          : Bell;

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: -12, scale: 0.97 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: -8, scale: 0.97 }}
      transition={{ duration: 0.18, ease: [0.16, 1, 0.3, 1] }}
      className={`pointer-events-auto w-full rounded-2xl border p-4 shadow-[0_16px_40px_-16px_rgba(15,42,30,0.28)] ${
        dark
          ? 'bg-[#13221A] border-[#2A4537] text-[#EFF6F2]'
          : 'bg-white border-[#C6DFCD] text-[#0F2A1E]'
      }`}
      role="status"
      aria-live="polite"
    >
      <div className="flex items-start gap-3">
        <div
          className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
            dark
              ? 'bg-[#1F6B48] text-[#9AD9B0]'
              : toast.category === 'graded'
                ? 'bg-[#114B32] text-white'
                : 'bg-[#E7F4EB] text-[#114B32]'
          }`}
        >
          <Icon className="w-4 h-4" />
        </div>

        <div className="min-w-0 flex-1 space-y-1">
          <div className="flex items-start justify-between gap-2">
            <p className="text-xs font-bold leading-snug">{toast.title}</p>
            <button
              type="button"
              onClick={() => onDismiss(toast.id)}
              className={`p-1 -m-1 rounded-lg transition-colors shrink-0 ${
                dark
                  ? 'text-[#9AB5A5] hover:bg-[#1E3328] hover:text-white'
                  : 'text-[#527361] hover:bg-[#EAF4ED] hover:text-[#0F2A1E]'
              }`}
              aria-label="Đóng thông báo"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>

          <p
            className={`text-xs leading-relaxed line-clamp-2 ${
              dark ? 'text-[#C5D8CD]' : 'text-[#426352]'
            }`}
          >
            {toast.message}
          </p>

          {toast.actionLabel && toast.onAction && (
            <div className="pt-1">
              <button
                type="button"
                onClick={() => {
                  toast.onAction?.();
                  onDismiss(toast.id);
                }}
                className={`text-xs font-bold hover:underline ${
                  dark ? 'text-[#9AD9B0]' : 'text-[#114B32]'
                }`}
              >
                {toast.actionLabel} →
              </button>
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
};

export const ToastViewport: React.FC<ToastViewportProps> = ({
  toasts,
  dark = false,
  onDismiss,
}) => {
  if (toasts.length === 0) return null;

  return (
    <div
      className="fixed top-4 right-4 left-4 sm:left-auto z-50 sm:w-[360px] flex flex-col gap-2.5 pointer-events-none"
      aria-label="Thông báo Nhiphoc"
    >
      <AnimatePresence initial={false}>
        {toasts.slice(0, 3).map((toast) => (
          <ToastItem key={toast.id} toast={toast} dark={dark} onDismiss={onDismiss} />
        ))}
      </AnimatePresence>
    </div>
  );
};
