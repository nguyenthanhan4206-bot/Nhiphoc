import React, { useState } from 'react';
import mascotImg from '../assets/images/nhiphoc_mascot_1794540512334.jpg';
import focusTreeImg from '../assets/images/focus_tree_hero_1794540512773.jpg';
import studyBannerImg from '../assets/images/study_sanctuary_banner_1794540514191.jpg';

export const MASCOT_IMAGE_PATH = mascotImg;
export const FOCUS_TREE_IMAGE_PATH = focusTreeImg;
export const STUDY_BANNER_IMAGE_PATH = studyBannerImg;

interface MascotAvatarProps {
  size?: 'sm' | 'md' | 'lg' | 'xl' | '2xl';
  dark?: boolean;
  className?: string;
}

export const MascotAvatar: React.FC<MascotAvatarProps> = ({
  size = 'md',
  dark = false,
  className = '',
}) => {
  const [imgError, setImgError] = useState(false);

  const dims = {
    sm: 'w-9 h-9 rounded-xl',
    md: 'w-11 h-11 rounded-2xl',
    lg: 'w-16 h-16 rounded-2xl',
    xl: 'w-24 h-24 rounded-3xl',
    '2xl': 'w-32 h-32 rounded-[28px]',
  }[size];

  const borderClass = dark
    ? 'border border-[#2A4537] bg-[#16271F]'
    : 'border border-[#C9E0D0] bg-[#EDF6F0]';

  if (imgError) {
    return (
      <div
        className={`${dims} ${borderClass} flex items-center justify-center shrink-0 overflow-hidden ${className}`}
        aria-label="Linh vật Nhiphoc"
      >
        <svg viewBox="0 0 64 64" className="w-4/5 h-4/5" fill="none">
          <path d="M32 10C34 6 39 5 42 8C39 11 35 12 32 10Z" fill="#2E8B57" />
          <path d="M32 10C30 6 25 5 22 8C25 11 29 12 32 10Z" fill="#4BA874" />
          <rect x="16" y="16" width="32" height="36" rx="16" fill="#114B32" />
          <circle cx="25" cy="30" r="6" fill="#FFFFFF" />
          <circle cx="39" cy="30" r="6" fill="#FFFFFF" />
          <circle cx="25" cy="30" r="2.6" fill="#0F2A1E" />
          <circle cx="39" cy="30" r="2.6" fill="#0F2A1E" />
          <path d="M29 36L32 41L35 36H29Z" fill="#A7D7B8" />
          <ellipse cx="32" cy="46" rx="10" ry="7" fill="#FFFFFF" />
        </svg>
      </div>
    );
  }

  return (
    <div className={`${dims} ${borderClass} shrink-0 overflow-hidden ${className}`}>
      <img
        src={MASCOT_IMAGE_PATH}
        alt="Linh vật cú mầm xanh Nhiphoc"
        referrerPolicy="no-referrer"
        onError={() => setImgError(true)}
        className="w-full h-full object-cover"
      />
    </div>
  );
};

export const NhiphocRhythmMark: React.FC<{ dark?: boolean; className?: string }> = ({
  dark = false,
  className = '',
}) => (
  <svg
    viewBox="0 0 96 20"
    fill="none"
    className={`h-4 w-auto ${className}`}
    aria-hidden="true"
  >
    <path
      d="M2 12C10 12 12 4 19 4C26 4 28 16 35 16C42 16 44 6 51 6C58 6 60 14 67 14C74 14 77 8 84 8C89 8 92 10 94 10"
      stroke={dark ? '#8CD4A6' : '#186A47'}
      strokeWidth="2.4"
      strokeLinecap="round"
    />
  </svg>
);
